@echo off
title NetScope — Starting...
setlocal EnableDelayedExpansion
set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"
set "SCRIPT=%DIR%\netscope.py"

:: Check if already admin
net session >nul 2>&1
if %ERRORLEVEL%==0 (
    echo [NetScope] Administrator detected — launching...
    python "%SCRIPT%"
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo [ERROR] Something went wrong.
        echo Troubleshooting:
        echo   1. python --version   ^(must be 3.8+^)
        echo   2. pip install scapy
        echo   3. Install Npcap from https://npcap.com/#download
        echo      ^(check "WinPcap API-compatible Mode"^)
        pause
    )
    goto :eof
)

:: Find Python
set PY=
where python >nul 2>&1 && set PY=python
if "!PY!"=="" where py >nul 2>&1 && set PY=py
if "!PY!"=="" (
    echo [ERROR] Python not found on PATH.
    echo Install Python from https://python.org
    echo Make sure to check "Add Python to PATH" during install.
    pause
    goto :eof
)

:: Elevate python.exe DIRECTLY (key fix for black window)
echo [NetScope] Requesting Administrator privileges...
echo [NetScope] Click YES on the UAC dialog to allow packet capture.
echo.
powershell -Command "Start-Process '!PY!' -ArgumentList '\"%SCRIPT%\"' -WorkingDirectory '%DIR%' -Verb RunAs -WindowStyle Normal"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Could not elevate automatically.
    echo Manual steps:
    echo   1. Right-click PowerShell ^> Run as administrator
    echo   2. cd /d "%DIR%"
    echo   3. python netscope.py
    pause
)
