"""
╔══════════════════════════════════════════════════════════════════╗
║  NetScope — Professional Network Packet Analyzer                ║
║  Auto-capture • Full protocol decode • Wireshark-identical UI   ║
║                                                                  ║
║  Usage:  python netscope.py  (as Administrator / sudo)          ║
║  Quick:  double-click  START.bat  (Windows)                     ║
╚══════════════════════════════════════════════════════════════════╝
"""

# ── Windows DPI fix — MUST be before ANY tkinter import ─────────────────────
import sys, os, platform
IS_WIN = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"

if IS_WIN:
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try: ctypes.windll.user32.SetProcessDPIAware()
        except Exception: pass

# ── stdlib imports ────────────────────────────────────────────────────────────
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, scrolledtext
import threading, queue, time, struct, socket, json
from datetime import datetime
from collections import Counter, defaultdict
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field

# ── Scapy ─────────────────────────────────────────────────────────────────────
try:
    from scapy.all import (
        sniff, get_if_list, get_if_addr, wrpcap, rdpcap, conf,
        IP, IPv6, TCP, UDP, ICMP, ARP, DNS, DNSQR, DNSRR,
        Raw, Ether, BOOTP, DHCP, NTP, Padding
    )
    SCAPY = True
except Exception as e:
    SCAPY = False
    SCAPY_ERR = str(e)

# ════════════════════════════════════════════════════════════════════════════
#  CONSTANTS & TABLES
# ════════════════════════════════════════════════════════════════════════════
PORT_SVC = {
    21:"FTP", 22:"SSH", 23:"Telnet", 25:"SMTP", 53:"DNS",
    67:"DHCP", 68:"DHCP", 80:"HTTP", 110:"POP3", 119:"NNTP",
    123:"NTP", 135:"MSRPC", 137:"NetBIOS", 139:"NetBIOS",
    143:"IMAP", 161:"SNMP", 179:"BGP", 389:"LDAP", 443:"HTTPS",
    445:"SMB", 465:"SMTPS", 514:"Syslog", 587:"Submission",
    636:"LDAPS", 993:"IMAPS", 995:"POP3S", 1080:"SOCKS",
    1194:"OpenVPN", 1433:"MSSQL", 1521:"Oracle", 1723:"PPTP",
    1883:"MQTT", 2049:"NFS", 3306:"MySQL", 3389:"RDP",
    5060:"SIP", 5432:"PostgreSQL", 5900:"VNC", 5672:"AMQP",
    6379:"Redis", 8080:"HTTP-Alt", 8443:"HTTPS-Alt",
    9200:"Elasticsearch", 27017:"MongoDB",
}

ICMP_TYPE = {
    0:"Echo Reply", 3:"Dest Unreachable", 4:"Source Quench",
    5:"Redirect", 8:"Echo Request", 9:"Router Advertisement",
    10:"Router Solicitation", 11:"Time Exceeded",
    12:"Parameter Problem",
}

TCP_FLAG_BITS = [
    (0x001,"FIN","F"),(0x002,"SYN","S"),(0x004,"RST","R"),
    (0x008,"PSH","P"),(0x010,"ACK","A"),(0x020,"URG","U"),
    (0x040,"ECE","E"),(0x080,"CWR","C"),
]

ETHERTYPES = {
    0x0800:"IPv4", 0x0806:"ARP", 0x86DD:"IPv6",
    0x8100:"802.1Q", 0x888E:"EAPOL", 0x8847:"MPLS",
}

DNS_QTYPES = {
    1:"A", 2:"NS", 5:"CNAME", 6:"SOA", 12:"PTR",
    15:"MX", 16:"TXT", 28:"AAAA", 33:"SRV", 255:"ANY",
}

def svc(port):
    return PORT_SVC.get(int(port) if str(port).isdigit() else 0, "")

def tcp_flags_short(f):
    return "".join(s for _,_,s in TCP_FLAG_BITS if f & _) or "·"

def tcp_flags_long(f):
    return ", ".join(n for b,n,_ in TCP_FLAG_BITS if f & b) or "None"

# ════════════════════════════════════════════════════════════════════════════
#  COLOUR THEME
# ════════════════════════════════════════════════════════════════════════════
BG   = "#12151c"
BG2  = "#191e28"
BG3  = "#1f2535"
BG4  = "#252d3f"
BG5  = "#2c3650"
BORD = "#2d3a52"
BORD2= "#3d5080"
ACC  = "#38bdf8"   # sky blue accent
ACC2 = "#0ea5e9"
GRN  = "#22d3ee"
GRN2 = "#06b6d4"
RED  = "#f87171"
RED2 = "#dc2626"
YEL  = "#fbbf24"
ORA  = "#fb923c"
PUR  = "#c084fc"
FG   = "#e2e8f0"
FG2  = "#94a3b8"
FG3  = "#475569"
FG4  = "#334155"
SEL  = "#1e3a5f"
SEL2 = "#e2e8f0"
HOFF = "#3b82f6"   # hex offset colour
HHEX = "#22d3ee"   # hex bytes colour
HASC = "#fb923c"   # hex ascii colour

# Protocol row colours  (fg, bg)
PROTO_COLORS = {
    "TCP":   (FG,   "#1a2235"),
    "UDP":   (FG,   "#121e2a"),
    "HTTP":  ("#bbf7d0","#0d1f10"),
    "HTTPS": ("#bbf7d0","#0a1a0e"),
    "TLS":   ("#bbf7d0","#0a1a0e"),
    "DNS":   ("#bfdbfe","#0d1529"),
    "DHCP":  ("#fef08a","#1e1700"),
    "ICMP":  ("#fed7aa","#1e0e00"),
    "ARP":   ("#a7f3d0","#04130c"),
    "NTP":   ("#ddd6fe","#130f20"),
}

# Special state overrides
RST_COLOR  = (RED,   "#2d0808")
SYN_COLOR  = ("#93c5fd","#0a1e3a")
RETX_COLOR = (YEL,   "#201200")
MARK_COLOR = (YEL,   "#2a1a00")

def row_color(rec):
    if rec.marked:     return MARK_COLOR
    if rec.is_retx:    return RETX_COLOR
    if "R" in rec.flags and rec.proto in ("TCP","HTTP","HTTPS","TLS"):
        return RST_COLOR
    if "S" in rec.flags and rec.proto in ("TCP","HTTP","HTTPS","TLS"):
        return SYN_COLOR
    return PROTO_COLORS.get(rec.proto, (FG, BG2))

# Fonts
if IS_WIN:
    MF,SF = "Consolas","Segoe UI"
elif IS_MAC:
    MF,SF = "Menlo","SF Pro Text"
else:
    MF,SF = "DejaVu Sans Mono","Ubuntu"

M  = (MF,10);  MS=(MF,9);   ML=(MF,11)
S  = (SF,10);  SB=(SF,10,"bold")
SS = (SF,9);   SL=(SF,13,"bold"); SXL=(SF,16,"bold")


# ════════════════════════════════════════════════════════════════════════════
#  DATA MODEL
# ════════════════════════════════════════════════════════════════════════════
@dataclass
class Pkt:
    num:       int
    t_abs:     float
    t_rel:     float
    t_delta:   float
    proto:     str
    src_ip:    str = ""
    dst_ip:    str = ""
    src_mac:   str = ""
    dst_mac:   str = ""
    src_port:  str = ""
    dst_port:  str = ""
    length:    int = 0
    flags:     str = ""
    ttl:       str = ""
    info:      str = ""
    layers:    List[Dict] = field(default_factory=list)
    raw:       bytes = b""
    payload:   bytes = b""
    stream_id: int   = -1
    marked:    bool  = False
    comment:   str   = ""
    is_retx:   bool  = False
    rtt_ms:    float = 0.0
    expert:    List[Tuple[str,str]] = field(default_factory=list)


# ════════════════════════════════════════════════════════════════════════════
#  PACKET PARSER
# ════════════════════════════════════════════════════════════════════════════
class Parser:
    def __init__(self):
        self.reset()

    def reset(self):
        self._t0 = None
        self._tp = None
        self._streams: Dict[tuple,int] = {}
        self._sn = 0
        self._syn_t: Dict[tuple,float] = {}
        self._seqs:  Dict[tuple,set]   = defaultdict(set)

    def parse(self, pkt, num: int) -> Pkt:
        now = float(getattr(pkt,"time",time.time()))
        if self._t0 is None: self._t0 = now
        rel   = now - self._t0
        delta = now - self._tp if self._tp else 0.0
        self._tp = now

        r = Pkt(num=num, t_abs=now, t_rel=rel, t_delta=delta,
                proto="Unknown", length=len(bytes(pkt)), raw=bytes(pkt))

        layers: List[Dict] = []

        # ── Frame ──────────────────────────────────────────────────────────
        ts = datetime.fromtimestamp(now).strftime("%Y-%m-%d %H:%M:%S.%f")
        layers.append({"ico":"📦","title":f"Frame {num}: {r.length} bytes on wire",
            "open":True,"fields":[
                ("Arrival Time", ts),
                ("Frame Number", str(num)),
                ("Frame Length", f"{r.length} bytes ({r.length*8} bits)"),
                ("Capture Length", f"{r.length} bytes"),
            ]})

        # ── Ethernet ───────────────────────────────────────────────────────
        if pkt.haslayer(Ether):
            e = pkt[Ether]
            r.src_mac, r.dst_mac = e.src, e.dst
            et = ETHERTYPES.get(e.type, f"0x{e.type:04X}")
            layers.append({"ico":"🔌","title":f"Ethernet II  Src: {e.src}  Dst: {e.dst}",
                "open":False,"fields":[
                    ("Destination", e.dst),
                    ("Source",      e.src),
                    ("Type",        f"{et} (0x{e.type:04X})"),
                ]})

        # ── ARP ────────────────────────────────────────────────────────────
        if pkt.haslayer(ARP):
            a = pkt[ARP]
            r.proto = "ARP"
            r.src_ip, r.dst_ip = a.psrc, a.pdst
            op = "request" if a.op==1 else "reply"
            r.info = (f"Who has {a.pdst}?  Tell {a.psrc}" if a.op==1
                      else f"{a.psrc} is at {a.hwsrc}")
            layers.append({"ico":"🔁","title":f"Address Resolution Protocol ({op})",
                "open":True,"fields":[
                    ("Opcode",      f"{op} ({a.op})"),
                    ("Sender MAC",  a.hwsrc),
                    ("Sender IP",   a.psrc),
                    ("Target MAC",  a.hwdst),
                    ("Target IP",   a.pdst),
                ]})
            if a.psrc == a.pdst:
                r.expert.append(("WARN","Gratuitous ARP — possible IP conflict"))
            r.layers = layers
            return r

        # ── IPv4 ───────────────────────────────────────────────────────────
        if pkt.haslayer(IP):
            ip = pkt[IP]
            r.src_ip, r.dst_ip = ip.src, ip.dst
            r.ttl = str(ip.ttl)
            df = bool(ip.flags & 0x2)
            ip_proto = {6:"TCP",17:"UDP",1:"ICMP",2:"IGMP",
                        47:"GRE",50:"ESP",89:"OSPF"}.get(ip.proto,str(ip.proto))
            layers.append({"ico":"🌐","title":f"Internet Protocol v4  Src: {ip.src}  Dst: {ip.dst}",
                "open":True,"fields":[
                    ("Version",          "4"),
                    ("Header Length",    f"{ip.ihl*4} bytes"),
                    ("Total Length",     str(ip.len)),
                    ("Identification",   f"0x{ip.id:04X} ({ip.id})"),
                    ("Flags",            f"{'DF ' if df else ''}0x{int(ip.flags):X}"),
                    ("TTL",              str(ip.ttl)),
                    ("Protocol",         f"{ip_proto} ({ip.proto})"),
                    ("Header Checksum",  f"0x{ip.chksum:04X}"),
                    ("Source",           ip.src),
                    ("Destination",      ip.dst),
                ]})
            if ip.ttl <= 1:
                r.expert.append(("WARN",f"TTL critically low ({ip.ttl})"))

        elif pkt.haslayer(IPv6):
            ip6 = pkt[IPv6]
            r.src_ip, r.dst_ip = ip6.src, ip6.dst
            r.ttl = str(ip6.hlim)
            layers.append({"ico":"🌐","title":f"Internet Protocol v6  Src: {ip6.src}  Dst: {ip6.dst}",
                "open":True,"fields":[
                    ("Version",          "6"),
                    ("Traffic Class",    f"0x{ip6.tc:02X}"),
                    ("Flow Label",       f"0x{ip6.fl:05X}"),
                    ("Payload Length",   str(ip6.plen)),
                    ("Next Header",      str(ip6.nh)),
                    ("Hop Limit",        str(ip6.hlim)),
                    ("Source",           ip6.src),
                    ("Destination",      ip6.dst),
                ]})

        # ── ICMP ───────────────────────────────────────────────────────────
        if pkt.haslayer(ICMP):
            ic = pkt[ICMP]
            r.proto = "ICMP"
            tname = ICMP_TYPE.get(ic.type, f"type {ic.type}")
            flds = [("Type",f"{ic.type} ({tname})"),
                    ("Code",str(ic.code)),
                    ("Checksum",f"0x{ic.chksum:04X}")]
            if ic.type in (0,8):
                flds += [("Identifier",str(ic.id)),
                         ("Sequence",  str(ic.seq))]
                r.info = (f"Echo {'request' if ic.type==8 else 'reply'}"
                          f"  id=0x{ic.id:04x}  seq={ic.seq}")
            else:
                r.info = tname
            layers.append({"ico":"📡","title":"Internet Control Message Protocol",
                "open":True,"fields":flds})
            if ic.type == 3:
                r.expert.append(("WARN",f"ICMP Destination Unreachable code={ic.code}"))

        # ── TCP ────────────────────────────────────────────────────────────
        if pkt.haslayer(TCP):
            tcp = pkt[TCP]
            r.src_port = str(tcp.sport)
            r.dst_port = str(tcp.dport)
            fi = int(tcp.flags)
            r.flags = tcp_flags_short(fi)
            sv = svc(tcp.sport) or svc(tcp.dport)

            # stream tracking
            key = tuple(sorted([(r.src_ip,tcp.sport),(r.dst_ip,tcp.dport)]))
            if key not in self._streams:
                self._streams[key] = self._sn; self._sn += 1
            r.stream_id = self._streams[key]

            # RTT: SYN → SYN-ACK
            sk = (r.src_ip,tcp.sport,r.dst_ip,tcp.dport)
            if fi&0x002 and not fi&0x010:
                self._syn_t[sk] = now
            elif fi&0x002 and fi&0x010:
                rev = (r.dst_ip,tcp.dport,r.src_ip,tcp.sport)
                if rev in self._syn_t:
                    r.rtt_ms = (now - self._syn_t.pop(rev))*1000

            # retransmit
            skey = tuple(sorted([(r.src_ip,tcp.sport),(r.dst_ip,tcp.dport)]))
            if tcp.seq in self._seqs[skey] and not (fi&0x002):
                r.is_retx = True
                r.expert.append(("WARN",f"TCP retransmission  seq={tcp.seq}"))
            self._seqs[skey].add(tcp.seq)

            # payload
            try: r.payload = bytes(tcp.payload)
            except: r.payload = b""

            flds = [
                ("Source Port",   f"{tcp.sport}" + (f"  ({sv})" if sv else "")),
                ("Dest Port",     f"{tcp.dport}" + (f"  ({svc(tcp.dport)})" if svc(tcp.dport) else "")),
                ("Stream Index",  str(r.stream_id)),
                ("Seq Number",    str(tcp.seq)),
                ("Ack Number",    str(tcp.ack) if fi&0x010 else "(not set)"),
                ("Header Length", f"{tcp.dataofs*4} bytes"),
                ("Flags",         f"0x{fi:03X}  ({tcp_flags_long(fi)})"),
                ("Window Size",   str(tcp.window)),
                ("Checksum",      f"0x{tcp.chksum:04X}"),
            ]
            if r.rtt_ms > 0:
                flds.append(("RTT",f"{r.rtt_ms:.3f} ms"))
            if tcp.options:
                opts = "  ".join(f"{o[0]}={o[1]}" if isinstance(o,tuple) and len(o)==2
                                  else str(o) for o in tcp.options[:5])
                flds.append(("Options",opts))

            if r.proto not in ("DNS","DHCP","HTTP","HTTPS","TLS","NTP"):
                r.proto = "TCP"
                plen = len(r.payload)
                sv2 = f" [{sv}]" if sv else ""
                r.info = (f"{tcp.sport} → {tcp.dport}{sv2}"
                          f"  [{tcp_flags_long(fi)}]"
                          f"  Seq={tcp.seq}  Ack={tcp.ack}"
                          f"  Win={tcp.window}  Len={plen}")
                if r.rtt_ms>0: r.info += f"  RTT={r.rtt_ms:.1f}ms"

            layers.append({"ico":"🔗","title":
                f"Transmission Control Protocol  {tcp.sport} → {tcp.dport}  [{tcp_flags_long(fi)}]",
                "open":True,"fields":flds})

            if fi&0x004: r.expert.append(("WARN","TCP RST — connection reset"))
            if tcp.window==0 and fi&0x010:
                r.expert.append(("WARN","TCP Zero Window — receiver buffer full"))

        # ── UDP ────────────────────────────────────────────────────────────
        elif pkt.haslayer(UDP):
            udp = pkt[UDP]
            r.src_port = str(udp.sport)
            r.dst_port = str(udp.dport)
            sv = svc(udp.sport) or svc(udp.dport)
            try: r.payload = bytes(udp.payload)
            except: r.payload = b""
            flds = [
                ("Source Port",  f"{udp.sport}" + (f"  ({sv})" if sv else "")),
                ("Dest Port",    f"{udp.dport}" + (f"  ({svc(udp.dport)})" if svc(udp.dport) else "")),
                ("Length",       str(udp.len)),
                ("Checksum",     f"0x{udp.chksum:04X}"),
            ]
            if r.proto not in ("DNS","DHCP","NTP","SNMP"):
                r.proto = "UDP"
                sv2 = f" [{sv}]" if sv else ""
                r.info = f"{udp.sport} → {udp.dport}{sv2}  Len={udp.len}"
            layers.append({"ico":"📨","title":
                f"User Datagram Protocol  {udp.sport} → {udp.dport}",
                "open":True,"fields":flds})

        # ── DNS ────────────────────────────────────────────────────────────
        if pkt.haslayer(DNS):
            dns = pkt[DNS]
            r.proto = "DNS"
            is_r = bool(dns.qr)
            flds = [
                ("Transaction ID", f"0x{dns.id:04X}"),
                ("Type",           "Response" if is_r else "Query"),
                ("Questions",      str(dns.qdcount)),
                ("Answer RRs",     str(dns.ancount)),
            ]
            qnames = []
            if pkt.haslayer(DNSQR):
                q = pkt[DNSQR]
                qn = q.qname.decode(errors="replace").rstrip(".")
                qt = DNS_QTYPES.get(q.qtype,str(q.qtype))
                qnames.append(f"{qn}  [{qt}]")
                flds.append(("Query",f"{qn}  type={qt}"))
            answers = []
            if is_r and dns.ancount>0:
                try:
                    an = dns.an
                    while an and hasattr(an,"rrname"):
                        rd = str(getattr(an,"rdata",""))
                        answers.append(rd)
                        flds.append(("Answer",f"{an.rrname.decode(errors='replace').rstrip('.')} → {rd}"))
                        an = an.payload if hasattr(an,"payload") else None
                except: pass
            if qnames:
                r.info = f"{'Response' if is_r else 'Query'} 0x{dns.id:04X}  {qnames[0]}"
                if answers: r.info += f"  → {', '.join(answers[:2])}"
            else:
                r.info = f"DNS {'Response' if is_r else 'Query'}  0x{dns.id:04X}"
            layers.append({"ico":"📛","title":
                "Domain Name System (response)" if is_r else "Domain Name System (query)",
                "open":True,"fields":flds})

        # ── DHCP ───────────────────────────────────────────────────────────
        if pkt.haslayer(BOOTP):
            bp = pkt[BOOTP]
            r.proto = "DHCP"
            mt = ""
            flds = [
                ("Message Type",    "Boot Request" if bp.op==1 else "Boot Reply"),
                ("Transaction ID",  f"0x{bp.xid:08X}"),
                ("Client IP",       str(bp.ciaddr)),
                ("Your IP",         str(bp.yiaddr)),
                ("Client MAC",      bp.chaddr.hex()[:12]),
            ]
            if pkt.haslayer(DHCP):
                mtypes = {1:"Discover",2:"Offer",3:"Request",4:"Decline",
                          5:"ACK",6:"NAK",7:"Release",8:"Inform"}
                for opt in pkt[DHCP].options:
                    if isinstance(opt,tuple):
                        if opt[0]=="message-type":
                            mt = mtypes.get(opt[1],str(opt[1]))
                            flds.append(("DHCP Message",mt))
                        elif opt[0]=="server_id":
                            flds.append(("Server ID",str(opt[1])))
                        elif opt[0]=="lease_time":
                            flds.append(("Lease Time",f"{opt[1]}s"))
            r.info = f"DHCP {mt}  xid=0x{bp.xid:08X}"
            layers.append({"ico":"🏠","title":"Dynamic Host Configuration Protocol",
                "open":True,"fields":flds})

        # ── NTP ────────────────────────────────────────────────────────────
        if pkt.haslayer(NTP):
            ntp = pkt[NTP]
            r.proto = "NTP"
            modes = {0:"Reserved",1:"Active",2:"Passive",3:"Client",
                     4:"Server",5:"Broadcast",6:"Control",7:"Private"}
            mode = modes.get(ntp.mode,"Unknown")
            r.info = f"NTP {mode}  v{ntp.version}  stratum={ntp.stratum}"
            layers.append({"ico":"⏱","title":"Network Time Protocol",
                "open":False,"fields":[
                    ("Version",  str(ntp.version)),
                    ("Mode",     f"{ntp.mode} ({mode})"),
                    ("Stratum",  str(ntp.stratum)),
                    ("Poll",     str(ntp.poll)),
                ]})

        # ── HTTP / TLS heuristic ───────────────────────────────────────────
        if r.payload and r.proto in ("TCP",):
            p = r.payload
            # HTTP
            HTTP_METHODS = (b"GET ",b"POST",b"PUT ",b"DELE",b"HEAD",
                            b"OPTI",b"PATC",b"CONN")
            if any(p[:4]==m for m in HTTP_METHODS) or p[:5]==b"HTTP/":
                r.proto = "HTTP"
                try:
                    txt   = p[:1024].decode("utf-8","replace")
                    lines = txt.split("\r\n")
                    r.info = lines[0][:100]
                    flds  = [("Request/Status",lines[0])]
                    for ln in lines[1:25]:
                        if ":" in ln:
                            k,_,v = ln.partition(":")
                            flds.append((k.strip(),v.strip()))
                    layers.append({"ico":"🌍","title":"Hypertext Transfer Protocol",
                        "open":True,"fields":flds})
                except: pass
            # TLS
            elif len(p)>=5 and p[0] in(0x14,0x15,0x16,0x17) \
                    and p[1:3] in (b"\x03\x01",b"\x03\x02",b"\x03\x03"):
                r.proto = "TLS"
                vers = {b"\x03\x01":"TLS 1.0",b"\x03\x02":"TLS 1.1",
                        b"\x03\x03":"TLS 1.2"}.get(p[1:3],"TLS")
                rtype = {0x14:"ChangeCipherSpec",0x15:"Alert",
                         0x16:"Handshake",0x17:"AppData"}.get(p[0],"Unknown")
                hs = ""
                if p[0]==0x16 and len(p)>=6:
                    hs = {1:"ClientHello",2:"ServerHello",11:"Certificate",
                          12:"ServerKeyExchange",14:"ServerHelloDone",
                          16:"ClientKeyExchange",20:"Finished"}.get(p[5],"")
                r.info = f"{vers}  {rtype}" + (f"  [{hs}]" if hs else "")
                layers.append({"ico":"🔒","title":f"Transport Layer Security ({vers})",
                    "open":False,"fields":[
                        ("Content Type",f"{p[0]} ({rtype})"),
                        ("Version",     vers),
                        ("Record Length",str(struct.unpack("!H",p[3:5])[0])),
                    ] + ([("Handshake Type",hs)] if hs else [])})

        # ── Raw data layer ─────────────────────────────────────────────────
        if pkt.haslayer(Raw) and r.payload:
            rd = bytes(pkt[Raw])
            if len(rd)>0:
                try: prev = rd[:48].decode("utf-8","replace").replace("\n"," ")[:50]
                except: prev = rd[:24].hex()
                layers.append({"ico":"💾","title":f"Data  ({len(rd)} bytes)",
                    "open":False,"fields":[("Length",f"{len(rd)} bytes"),
                                           ("Preview",prev)]})

        if not r.info: r.info = r.proto
        r.layers = layers
        return r


# ════════════════════════════════════════════════════════════════════════════
#  DISPLAY FILTER ENGINE
# ════════════════════════════════════════════════════════════════════════════
class Filter:
    PROTO = {
        "tcp":   lambda r: r.proto in ("TCP","HTTP","HTTPS","TLS"),
        "udp":   lambda r: r.proto in ("UDP","DNS","DHCP","NTP"),
        "http":  lambda r: r.proto == "HTTP",
        "https": lambda r: r.proto in ("HTTPS","TLS"),
        "tls":   lambda r: r.proto == "TLS",
        "ssl":   lambda r: r.proto == "TLS",
        "icmp":  lambda r: r.proto == "ICMP",
        "arp":   lambda r: r.proto == "ARP",
        "dns":   lambda r: r.proto == "DNS",
        "dhcp":  lambda r: r.proto == "DHCP",
        "ntp":   lambda r: r.proto == "NTP",
        "ip":    lambda r: bool(r.src_ip and ":" not in r.src_ip),
        "ipv6":  lambda r: bool(r.src_ip and ":" in r.src_ip),
        "tcp.analysis.retransmission": lambda r: r.is_retx,
        "retransmission": lambda r: r.is_retx,
        "expert": lambda r: bool(r.expert),
    }
    FIELDS = {
        "ip.src":      lambda r: r.src_ip,
        "ip.dst":      lambda r: r.dst_ip,
        "ip.addr":     "both_ip",
        "ipv6.src":    lambda r: r.src_ip,
        "ipv6.dst":    lambda r: r.dst_ip,
        "tcp.srcport": lambda r: r.src_port,
        "tcp.dstport": lambda r: r.dst_port,
        "tcp.port":    "both_port",
        "udp.srcport": lambda r: r.src_port,
        "udp.dstport": lambda r: r.dst_port,
        "udp.port":    "both_port",
        "eth.src":     lambda r: r.src_mac,
        "eth.dst":     lambda r: r.dst_mac,
        "eth.addr":    "both_mac",
        "frame.len":   lambda r: str(r.length),
        "frame.number":lambda r: str(r.num),
        "ip.ttl":      lambda r: r.ttl,
        "tcp.flags":   lambda r: r.flags,
        "tcp.stream":  lambda r: str(r.stream_id),
        "data.len":    lambda r: str(len(r.payload)),
    }

    @classmethod
    def match(cls, rec: Pkt, expr: str) -> bool:
        if not expr.strip(): return True
        try:    return cls._e(rec, expr.strip())
        except: return True

    @classmethod
    def _e(cls, r, x):
        x = x.strip()
        if x.startswith("(") and x.endswith(")"):
            inner = x[1:-1]
            d=0
            for c in inner:
                if c=="(":d+=1
                elif c==")":d-=1
                if d<0: break
            else:
                if d==0: return cls._e(r,inner)

        for op in [" or "," || "]:
            parts = cls._split(x, op)
            if parts: return any(cls._e(r,p) for p in parts)
        for op in [" and "," && "]:
            parts = cls._split(x, op)
            if parts: return all(cls._e(r,p) for p in parts)

        xl = x.lower()
        if xl.startswith("not "):  return not cls._e(r,x[4:].strip())
        if xl.startswith("!"):     return not cls._e(r,x[1:].strip())
        if xl in cls.PROTO:        return cls.PROTO[xl](r)

        for op in ("==","!=",">=","<=",">","<","contains","matches"):
            sep = f" {op} "
            if sep in x:
                lhs,rhs = x.split(sep,1)
                lhs = lhs.strip().lower()
                rhs = rhs.strip().strip('"\'')
                return cls._cmp(r,lhs,op,rhs)

        txt = x.strip('"\'').lower()
        return any(txt in str(v).lower() for v in [
            r.src_ip,r.dst_ip,r.src_port,r.dst_port,
            r.proto,r.info,r.src_mac,r.dst_mac])

    @classmethod
    def _split(cls,x,sep):
        parts,cur,d = [],""  ,0
        slen = len(sep)
        i = 0
        while i<len(x):
            if x[i]=="(": d+=1
            elif x[i]==")": d-=1
            if d==0 and x[i:i+slen].lower()==sep.lower():
                parts.append(cur.strip()); cur=""; i+=slen; continue
            cur+=x[i]; i+=1
        if parts: parts.append(cur.strip())
        return parts

    @classmethod
    def _cmp(cls,r,lhs,op,rhs):
        if lhs in ("ip.addr","ipv6.addr"):
            return cls._cv(r.src_ip,op,rhs) or cls._cv(r.dst_ip,op,rhs)
        if lhs in ("tcp.port","udp.port"):
            return cls._cv(r.src_port,op,rhs) or cls._cv(r.dst_port,op,rhs)
        if lhs == "eth.addr":
            return cls._cv(r.src_mac,op,rhs) or cls._cv(r.dst_mac,op,rhs)
        fn = cls.FIELDS.get(lhs)
        if fn is None or fn in ("both_ip","both_port","both_mac"): return True
        return cls._cv(fn(r),op,rhs)

    @staticmethod
    def _cv(val,op,rhs):
        if op=="==":       return val==rhs
        if op=="!=":       return val!=rhs
        if op in("contains","matches"): return rhs.lower() in val.lower()
        try:
            fv,fr = float(val),float(rhs)
            return {">=":fv>=fr,"<=":fv<=fr,">":fv>fr,"<":fv<fr}.get(op,False)
        except: return False

    @classmethod
    def validate(cls,expr):
        if not expr.strip(): return True,""
        try:
            test = Pkt(0,0,0,0,"TCP","1.1.1.1","2.2.2.2","","","80","443",64,"SA","64","t",[],b"")
            cls.match(test,expr)
            return True,"Filter OK"
        except Exception as e:
            return False,str(e)


# ════════════════════════════════════════════════════════════════════════════
#  STATISTICS ENGINE
# ════════════════════════════════════════════════════════════════════════════
class Stats:
    def __init__(self, pkts): self.p = pkts

    def proto_hier(self):
        total_p = len(self.p); total_b = sum(x.length for x in self.p)
        pc = Counter(x.proto for x in self.p)
        bc = defaultdict(int)
        for x in self.p: bc[x.proto]+=x.length
        return [(pr,c,bc[pr],c/total_p*100 if total_p else 0,
                 bc[pr]/total_b*100 if total_b else 0)
                for pr,c in pc.most_common()]

    def convos_ip(self):
        d={}
        for p in self.p:
            if not p.src_ip or not p.dst_ip: continue
            k=tuple(sorted([p.src_ip,p.dst_ip]))
            if k not in d:
                d[k]={"a":k[0],"b":k[1],"pa":0,"ba":0,"pb":0,"bb":0,
                      "t0":p.t_rel,"t1":p.t_rel}
            c=d[k]; c["t1"]=max(c["t1"],p.t_rel)
            if p.src_ip==k[0]: c["pa"]+=1;c["ba"]+=p.length
            else:               c["pb"]+=1;c["bb"]+=p.length
        return sorted(d.values(),key=lambda x:x["pa"]+x["pb"],reverse=True)

    def convos_tcp(self):
        d={}
        for p in self.p:
            if p.proto not in("TCP","HTTP","HTTPS","TLS") or not p.src_port: continue
            k=tuple(sorted([(p.src_ip,p.src_port),(p.dst_ip,p.dst_port)]))
            if k not in d:
                d[k]={"a":f"{k[0][0]}:{k[0][1]}","b":f"{k[1][0]}:{k[1][1]}",
                      "pkts":0,"bytes":0,"t0":p.t_rel,"t1":p.t_rel,"sid":p.stream_id}
            c=d[k]; c["pkts"]+=1;c["bytes"]+=p.length;c["t1"]=max(c["t1"],p.t_rel)
        return sorted(d.values(),key=lambda x:x["pkts"],reverse=True)

    def endpoints(self):
        d={}
        for p in self.p:
            for ip,dr in [(p.src_ip,"tx"),(p.dst_ip,"rx")]:
                if not ip: continue
                if ip not in d:
                    d[ip]={"addr":ip,"tx_p":0,"tx_b":0,"rx_p":0,"rx_b":0}
                d[ip][f"{dr}_p"]+=1;d[ip][f"{dr}_b"]+=p.length
        return sorted(d.values(),key=lambda x:x["tx_p"]+x["rx_p"],reverse=True)

    def io_graph(self,interval=1.0):
        if not self.p: return [],[],[]
        t0=self.p[0].t_rel; t1=self.p[-1].t_rel
        n=max(1,int((t1-t0)/interval)+1)
        pc=[0]*n; bc=[0]*n
        for p in self.p:
            i=min(n-1,int((p.t_rel-t0)/interval))
            pc[i]+=1; bc[i]+=p.length
        return [t0+i*interval for i in range(n)], pc, bc

    def expert(self):
        return [(p.num,sev,p.proto,msg) for p in self.p for sev,msg in p.expert]

    def follow_stream(self,sid):
        pkts=sorted([p for p in self.p if p.stream_id==sid],key=lambda x:x.t_abs)
        if not pkts: return "No packets in stream.","",""
        f=pkts[0]; cli=f"{f.src_ip}:{f.src_port}"; srv=f"{f.dst_ip}:{f.dst_port}"
        out=[]
        for p in pkts:
            if not p.payload: continue
            try: txt="".join(c if c.isprintable() or c in"\r\n\t" else "·"
                              for c in p.payload.decode("utf-8","replace"))
            except: txt=p.payload.hex()
            d="→" if f"{p.src_ip}:{p.src_port}"==cli else "←"
            out.append(f"\n── {d} {p.src_ip}:{p.src_port} → {p.dst_ip}:{p.dst_port}"
                       f"  ({len(p.payload)} bytes) ──\n{txt}")
        return "\n".join(out) if out else "No payload data.",cli,srv

    def dns_top(self):
        queries=[]
        for p in self.p:
            if p.proto!="DNS": continue
            for part in p.info.split():
                if "." in part and not part.startswith("0x") and len(part)>3:
                    queries.append(part.rstrip("."))
        return Counter(queries).most_common(30)


# ════════════════════════════════════════════════════════════════════════════
#  UI HELPERS
# ════════════════════════════════════════════════════════════════════════════
def _tree(parent, cols, hdrs, widths, anchors=None, **kw):
    t = ttk.Treeview(parent, columns=cols, show="headings", **kw)
    for i,(c,h,w) in enumerate(zip(cols,hdrs,widths)):
        a = (anchors[i] if anchors else "w")
        t.heading(c,text=h); t.column(c,width=w,minwidth=28,anchor=a,stretch=(i==len(cols)-1))
    return t

def _btn(parent, text, fg=None, cmd=None, padx=10, pady=4, **kw):
    return tk.Button(parent,text=text,bg=BG4,fg=fg or FG2,
                     font=SB,relief="flat",padx=padx,pady=pady,
                     cursor="hand2",activebackground=BG5,
                     activeforeground=fg or FG,command=cmd,**kw)

def _vsb(parent,widget):
    s=ttk.Scrollbar(parent,orient="vertical",command=widget.yview)
    widget.configure(yscrollcommand=s.set); return s

def _hsb(parent,widget):
    s=ttk.Scrollbar(parent,orient="horizontal",command=widget.xview)
    widget.configure(xscrollcommand=s.set); return s


# ════════════════════════════════════════════════════════════════════════════
#  STATISTICS DIALOGS
# ════════════════════════════════════════════════════════════════════════════
class _Dlg(tk.Toplevel):
    def __init__(self,par,title,w=840,h=520):
        super().__init__(par); self.title(title)
        self.configure(bg=BG); self.geometry(f"{w}x{h}")
        self.transient(par)
    def _hdr(self,t):
        tk.Label(self,text=t,bg=BG,fg=ACC,font=SL).pack(padx=16,pady=(10,6),anchor="w")
    def _cls(self):
        _btn(self,"Close",FG2,self.destroy).pack(pady=8,side="bottom")
    def _tf(self,par,cols,hdrs,widths,anchors=None,h=14):
        f=tk.Frame(par,bg=BG2); f.pack(fill="both",expand=True,padx=8,pady=4)
        t=_tree(f,cols,hdrs,widths,anchors,height=h)
        vs=_vsb(f,t); hs=_hsb(f,t)
        vs.pack(side="right",fill="y"); hs.pack(side="bottom",fill="x")
        t.pack(fill="both",expand=True); return t


class ProtoDialog(_Dlg):
    def __init__(self,par,pkts):
        super().__init__(par,"Protocol Hierarchy Statistics",860,460)
        self._hdr("Protocol Hierarchy Statistics")
        t=self._tf(self,("pr","pc","pp","bc","bp"),
                   ("Protocol","Packets","% Pkts","Bytes","% Bytes"),
                   [170,90,70,120,80],["w","e","e","e","e"])
        t.tag_configure("r0",foreground=ACC); t.tag_configure("r1",foreground=GRN)
        s=Stats(pkts)
        dur=max(pkts[-1].t_rel-pkts[0].t_rel,0.001) if len(pkts)>1 else 1
        for i,(pr,pc,bc,pp,bp) in enumerate(s.proto_hier()):
            t.insert("","end",tags=(f"r{min(i,1)}",),
                values=(pr,f"{pc:,}",f"{pp:.1f}%",f"{bc:,}",f"{bp:.1f}%"))
        self._cls()


class ConvoDialog(_Dlg):
    def __init__(self,par,pkts):
        super().__init__(par,"Conversations",1000,520)
        self._hdr("Conversations")
        nb=ttk.Notebook(self); nb.pack(fill="both",expand=True,padx=8,pady=4)
        s=Stats(pkts)
        # IPv4
        f1=tk.Frame(nb,bg=BG); nb.add(f1,text="  IPv4  ")
        t1=self._tf(f1,("a","b","pa","ba","pb","bb","tot","dur"),
                    ("Address A","Address B","Pkts A→B","Bytes A→B",
                     "Pkts B→A","Bytes B→A","Total","Duration"),
                    [145,145,80,100,80,100,80,90],["w","w","e","e","e","e","e","e"])
        for c in s.convos_ip()[:500]:
            dur=c["t1"]-c["t0"]
            t1.insert("","end",values=(c["a"],c["b"],
                f"{c['pa']:,}",f"{c['ba']:,}",f"{c['pb']:,}",f"{c['bb']:,}",
                f"{c['pa']+c['pb']:,}",f"{dur:.3f}s"))
        # TCP
        f2=tk.Frame(nb,bg=BG); nb.add(f2,text="  TCP  ")
        t2=self._tf(f2,("a","b","pkts","bytes","dur","sid"),
                    ("Endpoint A","Endpoint B","Packets","Bytes","Duration","Stream"),
                    [200,200,80,100,80,70],["w","w","e","e","e","e"])
        for c in s.convos_tcp()[:300]:
            t2.insert("","end",values=(c["a"],c["b"],
                f"{c['pkts']:,}",f"{c['bytes']:,}",
                f"{c['t1']-c['t0']:.3f}s",c["sid"]))
        self._cls()


class EndpointDialog(_Dlg):
    def __init__(self,par,pkts):
        super().__init__(par,"Endpoints",860,480)
        self._hdr("Endpoints — IPv4")
        t=self._tf(self,("addr","tp","tb","rp","rb","tot"),
                   ("Address","Tx Packets","Tx Bytes","Rx Packets","Rx Bytes","Total"),
                   [175,95,110,95,110,90],["w","e","e","e","e","e"])
        t.tag_configure("top",foreground=ACC)
        s=Stats(pkts)
        for i,ep in enumerate(s.endpoints()[:400]):
            tag=("top",) if i<3 else ()
            t.insert("","end",tags=tag,
                values=(ep["addr"],f"{ep['tx_p']:,}",f"{ep['tx_b']:,}",
                        f"{ep['rx_p']:,}",f"{ep['rx_b']:,}",
                        f"{ep['tx_p']+ep['rx_p']:,}"))
        self._cls()


class IODialog(_Dlg):
    def __init__(self,par,pkts):
        super().__init__(par,"I/O Graph",940,560)
        self._pkts=pkts
        self._iv=tk.StringVar(value="1.0")
        self._mv=tk.StringVar(value="packets")
        self._hdr("I/O Graph")
        ctrl=tk.Frame(self,bg=BG3); ctrl.pack(fill="x",padx=8,pady=4)
        tk.Label(ctrl,text="Interval:",bg=BG3,fg=FG2,font=S).pack(side="left",padx=8,pady=4)
        for v in("0.1","0.25","0.5","1.0","5.0","10.0","60.0"):
            tk.Radiobutton(ctrl,text=f"{v}s",variable=self._iv,value=v,
                bg=BG3,fg=FG2,selectcolor=BG3,activebackground=BG3,
                font=SS,command=self._draw).pack(side="left",padx=3)
        tk.Label(ctrl,text=" │ ",bg=BG3,fg=FG3,font=S).pack(side="left")
        for v,t in [("packets","Packets/s"),("bytes","Bytes/s")]:
            tk.Radiobutton(ctrl,text=t,variable=self._mv,value=v,
                bg=BG3,fg=FG2,selectcolor=BG3,activebackground=BG3,
                font=SS,command=self._draw).pack(side="left",padx=4)
        self._canvas=tk.Canvas(self,bg=BG2,highlightthickness=0,height=390)
        self._canvas.pack(fill="both",expand=True,padx=8,pady=4)
        self._canvas.bind("<Configure>",lambda e:self._draw())
        self._draw()
        self._cls()

    def _draw(self):
        c=self._canvas; c.delete("all")
        s=Stats(self._pkts)
        times,pc,bc=s.io_graph(float(self._iv.get()))
        vals=bc if self._mv.get()=="bytes" else pc
        W=c.winfo_width() or 880; H=c.winfo_height() or 370
        pL,pR,pT,pB=70,24,24,48
        if not vals: return
        maxv=max(vals) or 1; n=len(vals)
        def tx(i): return pL+i/max(n-1,1)*(W-pL-pR)
        def ty(v):  return pT+(1-v/maxv)*(H-pT-pB)
        for i in range(6):
            y=pT+i*(H-pT-pB)/5; v=maxv*(1-i/5)
            c.create_line(pL,y,W-pR,y,fill=BORD,dash=(3,6))
            lbl=f"{int(v):,}" if v<1e4 else f"{v/1000:.1f}k"
            c.create_text(pL-5,y,text=lbl,anchor="e",fill=FG3,font=MS)
        step=max(1,n//10)
        for i in range(0,n,step):
            x=tx(i); c.create_line(x,H-pB,x,H-pB+4,fill=FG3)
            c.create_text(x,H-pB+6,text=f"{times[i]:.1f}",anchor="n",fill=FG3,font=MS)
        c.create_line(pL,pT,pL,H-pB,fill=FG3,width=1)
        c.create_line(pL,H-pB,W-pR,H-pB,fill=FG3,width=1)
        bw=max(1,(W-pL-pR)/n-1)
        for i,v in enumerate(vals):
            x=tx(i); y=ty(v)
            c.create_rectangle(x-bw/2,y,x+bw/2,H-pB,fill=ACC2,outline="")
        pts=[]
        for i,v in enumerate(vals): pts.extend([tx(i),ty(v)])
        if len(pts)>=4: c.create_line(*pts,fill=ACC,width=2,smooth=True)
        pi=vals.index(maxv)
        c.create_oval(tx(pi)-4,ty(maxv)-4,tx(pi)+4,ty(maxv)+4,fill=GRN,outline="")
        c.create_text(W-pR,pT-8,text=f"Peak: {maxv:,}",anchor="e",fill=GRN,font=MS)
        ylabel="Bytes/s" if self._mv.get()=="bytes" else "Packets/s"
        c.create_text(pL+(W-pL-pR)/2,H-6,text="Time (s)",fill=FG3,font=SS)
        c.create_text(14,H/2,text=ylabel,fill=FG3,font=SS,angle=90)


class ExpertDialog(_Dlg):
    def __init__(self,par,pkts):
        super().__init__(par,"Expert Information",880,480)
        self._hdr("Expert Information")
        s=Stats(pkts); infos=s.expert()
        warns=sum(1 for _,sv,_,_ in infos if sv=="WARN")
        notes=sum(1 for _,sv,_,_ in infos if sv=="NOTE")
        sb=tk.Frame(self,bg=BG3); sb.pack(fill="x",padx=8,pady=4)
        tk.Label(sb,text=f"  ⚠ Warnings: {warns}   ℹ Notes: {notes}",
                 bg=BG3,fg=YEL,font=SB).pack(side="left",padx=8,pady=4)
        t=self._tf(self,("num","sev","proto","msg"),
                   ("Pkt","Severity","Protocol","Message"),
                   [60,90,90,540],["e","w","w","w"])
        t.tag_configure("W",foreground=RED); t.tag_configure("N",foreground=YEL)
        for num,sev,proto,msg in infos:
            t.insert("","end",values=(num,sev,proto,msg),
                     tags=("W" if sev=="WARN" else "N",))
        if not infos:
            t.insert("","end",values=("—","—","—","✓  No issues found"))
        self._cls()


class StreamDialog(tk.Toplevel):
    def __init__(self,par,txt,cli,srv,sid):
        super().__init__(par); self.title(f"Follow TCP Stream — Stream {sid}")
        self.configure(bg=BG); self.geometry("980x640"); self.transient(par)
        tk.Label(self,text=f"  🔗  TCP Stream {sid}   {cli}  ⟷  {srv}",
                 bg=BG3,fg=ACC,font=SB,anchor="w").pack(fill="x")
        self._box=scrolledtext.ScrolledText(self,bg=BG2,fg=FG,font=M,
            relief="flat",insertbackground=GRN,wrap="none",state="disabled")
        self._box.pack(fill="both",expand=True)
        self._box.configure(state="normal")
        self._box.insert("end",txt if txt else "No payload data in stream.")
        self._box.configure(state="disabled")
        btns=tk.Frame(self,bg=BG); btns.pack(fill="x",pady=6)
        _btn(btns,"💾  Save As…",ACC,self._save,padx=12).pack(side="left",padx=8)
        _btn(btns,"📋  Copy",FG2,
             lambda:[self.clipboard_clear(),self.clipboard_append(txt)],
             padx=10).pack(side="left",padx=4)
        _btn(btns,"Close",FG2,self.destroy,padx=12).pack(side="right",padx=8)

    def _save(self):
        p=filedialog.asksaveasfilename(defaultextension=".txt",
            filetypes=[("Text","*.txt"),("All","*.*")])
        if p:
            with open(p,"w",encoding="utf-8",errors="replace") as f:
                f.write(self._box.get("1.0","end"))


# ════════════════════════════════════════════════════════════════════════════
#  HEX PANE
# ════════════════════════════════════════════════════════════════════════════
class HexPane(tk.Frame):
    BPR=16
    def __init__(self,par,**kw):
        super().__init__(par,bg=BG2,**kw)
        h=tk.Frame(self,bg=BG3,height=24); h.pack(fill="x"); h.pack_propagate(False)
        tk.Label(h,text=" ⬡  Packet Bytes",bg=BG3,fg=ACC,font=SB,anchor="w"
                 ).pack(side="left",padx=6)
        self._llen=tk.Label(h,text="",bg=BG3,fg=FG2,font=MS)
        self._llen.pack(side="right",padx=8)
        self._txt=tk.Text(self,bg=BG2,fg=FG,font=MS,relief="flat",
            wrap="none",state="disabled",cursor="arrow",
            selectbackground=SEL,selectforeground=SEL2,spacing1=1)
        vs=_vsb(self,self._txt); hs=_hsb(self,self._txt)
        vs.pack(side="right",fill="y"); hs.pack(side="bottom",fill="x")
        self._txt.pack(fill="both",expand=True)
        for t,c in [("O",HOFF),("B",HHEX),("S",BG5),("A",HASC),
                    ("D",FG4),("H",FG3),("X",HHEX)]:
            self._txt.tag_configure(t,foreground=c)
        self._txt.tag_configure("X",background=SEL)

    def show(self,data:bytes,hl_s=-1,hl_e=-1):
        self._txt.configure(state="normal"); self._txt.delete("1.0","end")
        self._llen.configure(text=f"{len(data)} bytes")
        if not data:
            self._txt.insert("end","  No data","D")
            self._txt.configure(state="disabled"); return
        n=self.BPR
        hdr="  Offset    "+" ".join(f"{i:02X}" for i in range(n))+"   │  ASCII\n"
        self._txt.insert("end",hdr,"H")
        self._txt.insert("end","  "+"─"*68+"\n","S")
        for r0 in range(0,len(data),n):
            row=data[r0:r0+n]
            self._txt.insert("end",f"  {r0:06X}  ","O")
            for i,b in enumerate(row):
                ai=r0+i
                tag="X" if hl_s<=ai<hl_e else "B"
                self._txt.insert("end",f"{b:02X}",tag)
                self._txt.insert("end","  " if i==7 else " ","S")
            pad=n-len(row)
            self._txt.insert("end","   "*pad+(" " if pad>8 else ""),"S")
            self._txt.insert("end"," │  ","S")
            for b in row:
                if 32<=b<127: self._txt.insert("end",chr(b),"A")
                else:          self._txt.insert("end","·","D")
            self._txt.insert("end","\n")
        self._txt.configure(state="disabled")

    def clear(self):
        self._txt.configure(state="normal"); self._txt.delete("1.0","end")
        self._txt.configure(state="disabled"); self._llen.configure(text="")


# ════════════════════════════════════════════════════════════════════════════
#  DETAIL PANE
# ════════════════════════════════════════════════════════════════════════════
class DetailPane(tk.Frame):
    def __init__(self,par,**kw):
        super().__init__(par,bg=BG2,**kw)
        h=tk.Frame(self,bg=BG3,height=24); h.pack(fill="x"); h.pack_propagate(False)
        tk.Label(h,text=" ◈  Packet Details",bg=BG3,fg=ACC,font=SB,anchor="w"
                 ).pack(side="left",padx=6)
        self._sl=tk.Label(h,text="",bg=BG3,fg=FG2,font=MS)
        self._sl.pack(side="right",padx=8)
        self._tree=ttk.Treeview(self,show="tree",selectmode="browse")
        self._tree.column("#0",width=640,minwidth=200)
        vs=_vsb(self,self._tree); hs=_hsb(self,self._tree)
        vs.pack(side="right",fill="y"); hs.pack(side="bottom",fill="x")
        self._tree.pack(fill="both",expand=True)
        for tag,fg,bold in [("L",ACC,True),("F",FG,False),
                              ("W",RED,False),("N",YEL,False),("OK",GRN,False)]:
            font=SB if bold else S
            self._tree.tag_configure(tag,foreground=fg,font=font)

    def show(self,rec:Pkt):
        self._tree.delete(*self._tree.get_children())
        if not rec: return
        self._sl.configure(text=f"#{rec.num}  {rec.proto}  {rec.length}B")
        for layer in rec.layers:
            pid=self._tree.insert("","end",
                text=f"  {layer['ico']}  {layer['title']}",
                open=layer.get("open",True),tags=("L",))
            for k,v in layer.get("fields",[]):
                if not str(v).strip(): continue
                self._tree.insert(pid,"end",text=f"    {k}:  {v}",tags=("F",))
        if rec.expert:
            ep=self._tree.insert("","end",text="  ⚠  Expert Information",
                open=True,tags=("L",))
            for sev,msg in rec.expert:
                t="W" if sev=="WARN" else "N"
                icon="⚠" if sev=="WARN" else "ℹ"
                self._tree.insert(ep,"end",text=f"    {icon}  {msg}",tags=(t,))
        if rec.is_retx:
            self._tree.insert("","end",text="  🔄  TCP Retransmission detected",tags=("W",))
        if rec.rtt_ms>0:
            self._tree.insert("","end",text=f"  ⏱  RTT: {rec.rtt_ms:.3f} ms",tags=("OK",))
        if rec.comment:
            self._tree.insert("","end",text=f"  💬  {rec.comment}",tags=("N",))

    def clear(self):
        self._tree.delete(*self._tree.get_children()); self._sl.configure(text="")


# ════════════════════════════════════════════════════════════════════════════
#  PACKET LIST PANE
# ════════════════════════════════════════════════════════════════════════════
class PktList(tk.Frame):
    COLS=[("no","No.",58,"e"),("time","Time",104,"w"),
          ("src","Source",185,"w"),("dst","Destination",185,"w"),
          ("proto","Protocol",82,"w"),("len","Len",58,"e"),
          ("flags","Flags",60,"w"),("info","Info",560,"w")]

    def __init__(self,par,on_select=None,**kw):
        super().__init__(par,bg=BG2,**kw)
        self._on_select=on_select
        self._all:List[Pkt]=[]
        self._tmode="relative"
        self._sort_col=None; self._sort_rev=False
        self._build()

    def _build(self):
        h=tk.Frame(self,bg=BG3,height=24); h.pack(fill="x"); h.pack_propagate(False)
        self._hl=tk.Label(h,text=" ◉  Packet List",bg=BG3,fg=ACC,font=SB,anchor="w")
        self._hl.pack(side="left",padx=6)
        self._rl=tk.Label(h,text="",bg=BG3,fg=GRN,font=MS)
        self._rl.pack(side="right",padx=8)

        f=tk.Frame(self,bg=BG2); f.pack(fill="both",expand=True)
        cols=[c[0] for c in self.COLS]
        self._t=ttk.Treeview(f,columns=cols,show="headings",selectmode="extended")
        for cid,hdr,w,anc in self.COLS:
            self._t.heading(cid,text=hdr,command=lambda c=cid:self._sort(c))
            self._t.column(cid,width=w,minwidth=26,anchor=anc,stretch=(cid=="info"))
        vs=_vsb(f,self._t); hs=_hsb(f,self._t)
        vs.pack(side="right",fill="y"); hs.pack(side="bottom",fill="x")
        self._t.pack(fill="both",expand=True)
        self._t.bind("<<TreeviewSelect>>",self._sel)
        self._t.bind("<Button-3>",self._ctx)

        self._menu=tk.Menu(self,tearoff=0,bg=BG3,fg=FG,
            activebackground=SEL,activeforeground=SEL2,font=SS,bd=1)
        for lbl,cmd in [
            ("🔗  Follow TCP Stream",self._follow),
            ("📋  Apply as Filter",  self._as_filt),
            ("🚫  Exclude Protocol", self._excl),
            (None,None),
            ("⭐  Mark / Unmark",    self._mark),
            ("💬  Add Comment…",    self._comment),
            (None,None),
            ("📋  Copy Summary",     self._copy_sum),
            ("📋  Copy Source IP",   self._copy_src),
            ("📋  Copy Dest IP",     self._copy_dst),
            ("📋  Copy as CSV",      self._copy_csv),
        ]:
            if lbl: self._menu.add_command(label=lbl,command=cmd)
            else:   self._menu.add_separator()

    def _tfmt(self,r:Pkt)->str:
        if self._tmode=="absolute":
            return datetime.fromtimestamp(r.t_abs).strftime("%H:%M:%S.%f")[:-3]
        if self._tmode=="delta": return f"{r.t_delta:.6f}"
        return f"{r.t_rel:.6f}"

    def append(self,rec:Pkt,filt=""):
        self._all.append(rec)
        if not filt or Filter.match(rec,filt):
            self._insert(rec)

    def _insert(self,rec:Pkt):
        src=(rec.src_ip or rec.src_mac or "?")
        dst=(rec.dst_ip or rec.dst_mac or "?")
        if rec.src_port: src+=f":{rec.src_port}"
        if rec.dst_port: dst+=f":{rec.dst_port}"
        fg,bg=row_color(rec)
        tag=f"t{rec.num}"
        self._t.tag_configure(tag,foreground=fg,background=bg)
        self._t.insert("","end",iid=str(rec.num),tags=(tag,),
            values=(rec.num,self._tfmt(rec),src,dst,
                    rec.proto,rec.length,rec.flags,rec.info))

    def apply_filter(self,filt)->int:
        self._t.delete(*self._t.get_children())
        m=0
        for rec in self._all:
            if Filter.match(rec,filt): self._insert(rec); m+=1
        self._hl.configure(text=f" ◉  Packet List  ({m:,}/{len(self._all):,})")
        return m

    def clear(self):
        self._t.delete(*self._t.get_children())
        self._all.clear()
        self._hl.configure(text=" ◉  Packet List")

    def selected(self)->Optional[Pkt]:
        sel=self._t.selection()
        if not sel: return None
        try:
            n=int(sel[0])
            return next((p for p in self._all if p.num==n),None)
        except: return None

    def select(self,num:int):
        try: self._t.selection_set(str(num)); self._t.see(str(num))
        except: pass

    def scroll_end(self):
        ch=self._t.get_children()
        if ch: self._t.see(ch[-1])

    def refresh(self):
        self._t.delete(*self._t.get_children())
        for rec in self._all: self._insert(rec)

    def set_rate(self,txt): self._rl.configure(text=txt)

    def _sel(self,_=None):
        rec=self.selected()
        if rec and self._on_select: self._on_select(rec)

    def _ctx(self,e):
        row=self._t.identify_row(e.y)
        if row: self._t.selection_set(row)
        try: self._menu.tk_popup(e.x_root,e.y_root)
        finally: self._menu.grab_release()

    def _sort(self,col):
        data=[(self._t.set(k,col),k) for k in self._t.get_children()]
        if self._sort_col==col: self._sort_rev=not self._sort_rev
        else: self._sort_col=col; self._sort_rev=False
        try: data.sort(key=lambda t:float(t[0]),reverse=self._sort_rev)
        except: data.sort(reverse=self._sort_rev)
        for i,(_,k) in enumerate(data): self._t.move(k,"",i)
        arr=" ↑" if not self._sort_rev else " ↓"
        for cid,hdr,_,_ in self.COLS:
            self._t.heading(cid,text=hdr+(arr if cid==col else ""))

    def _mark(self):
        rec=self.selected()
        if not rec: return
        rec.marked=not rec.marked
        fg,bg=row_color(rec)
        self._t.tag_configure(f"t{rec.num}",foreground=fg,background=bg)

    def _comment(self):
        rec=self.selected()
        if not rec: return
        c=simpledialog.askstring("Comment",f"Comment for packet #{rec.num}:",
            initialvalue=rec.comment,parent=self)
        if c is not None: rec.comment=c

    def _follow(self):     self.event_generate("<<FollowStream>>")
    def _as_filt(self):    self.event_generate("<<ApplyFilter>>",data=self.selected().proto.lower() if self.selected() else "")
    def _excl(self):       self.event_generate("<<ApplyFilter>>",data=f"not {self.selected().proto.lower()}" if self.selected() else "")

    def _copy_sum(self):
        r=self.selected()
        if r: self.clipboard_clear(); self.clipboard_append(f"{r.num}\t{r.t_rel:.6f}\t{r.src_ip}\t{r.dst_ip}\t{r.proto}\t{r.length}\t{r.info}")
    def _copy_src(self):
        r=self.selected()
        if r: self.clipboard_clear(); self.clipboard_append(r.src_ip)
    def _copy_dst(self):
        r=self.selected()
        if r: self.clipboard_clear(); self.clipboard_append(r.dst_ip)
    def _copy_csv(self):
        r=self.selected()
        if r: self.clipboard_clear(); self.clipboard_append(f"{r.num},{r.t_rel:.6f},{r.src_ip},{r.dst_ip},{r.proto},{r.length},\"{r.info}\"")

    def find(self,q)->Optional[int]:
        q=q.lower()
        for r in self._all:
            if any(q in str(v).lower() for v in [r.src_ip,r.dst_ip,r.src_port,r.dst_port,r.proto,r.info,r.src_mac,r.dst_mac,str(r.num)]):
                return r.num
        return None

    def set_time_mode(self,mode):
        self._tmode=mode
        for ch in self._t.get_children():
            try:
                n=int(ch); rec=next((p for p in self._all if p.num==n),None)
                if rec:
                    v=list(self._t.item(ch,"values")); v[1]=self._tfmt(rec)
                    self._t.item(ch,values=v)
            except: pass


# ════════════════════════════════════════════════════════════════════════════
#  FILTER BAR
# ════════════════════════════════════════════════════════════════════════════
class FilterBar(tk.Frame):
    QUICK=[("All",""),("TCP","tcp"),("UDP","udp"),("HTTP","http"),
           ("HTTPS","tls"),("DNS","dns"),("ICMP","icmp"),("ARP","arp"),
           ("DHCP","dhcp"),("No ARP","not arp"),("Errors","expert"),
           ("TCP SYN","tcp.flags == 0x002"),("Retrans","retransmission")]

    def __init__(self,par,on_apply=None,**kw):
        super().__init__(par,bg=BG3,**kw)
        self._cb=on_apply; self._hist=[]
        self._build()

    def _build(self):
        top=tk.Frame(self,bg=BG3); top.pack(fill="x",padx=6,pady=3)
        tk.Label(top,text=" ⚡ Display Filter:",bg=BG3,fg=ACC,font=SB
                 ).pack(side="left",padx=(2,6))
        self._v=tk.StringVar()
        self._v.trace_add("write",self._validate)
        self._e=tk.Entry(top,textvariable=self._v,bg=BG4,fg=GRN,
            insertbackground=GRN,relief="flat",font=M,
            highlightthickness=2,highlightcolor=BORD,highlightbackground=BORD)
        self._e.pack(side="left",fill="x",expand=True,ipady=5)
        self._e.bind("<Return>",   lambda e:self._apply())
        self._e.bind("<KP_Enter>", lambda e:self._apply())
        self._e.bind("<Escape>",   lambda e:self._clear())
        _btn(top,"▶  Apply",GRN,self._apply,padx=10,pady=3
             ).pack(side="left",padx=4)
        _btn(top,"✕  Clear",FG2,self._clear,padx=8,pady=3
             ).pack(side="left",padx=2)
        self._sl=tk.Label(top,text="",bg=BG3,fg=FG2,font=SS,width=8)
        self._sl.pack(side="left",padx=4)

        qrow=tk.Frame(self,bg=BG3); qrow.pack(fill="x",padx=6,pady=(0,3))
        tk.Label(qrow,text="Quick:",bg=BG3,fg=FG3,font=SS).pack(side="left",padx=(2,4))
        for lbl,filt in self.QUICK:
            tk.Button(qrow,text=lbl,bg=BG4,fg=FG2,font=SS,
                relief="flat",padx=5,pady=1,cursor="hand2",
                activebackground=BG5,
                command=lambda f=filt:self._set(f)).pack(side="left",padx=1)

    def _validate(self,*_):
        expr=self._v.get().strip()
        if not expr:
            self._e.configure(highlightbackground=BORD,bg=BG4)
            self._sl.configure(text=""); return
        ok,_=Filter.validate(expr)
        if ok:
            self._e.configure(highlightbackground=GRN2,bg="#001a0a")
            self._sl.configure(text="✓",fg=GRN)
        else:
            self._e.configure(highlightbackground=RED2,bg="#1a0000")
            self._sl.configure(text="✗",fg=RED)

    def _apply(self):
        f=self._v.get().strip()
        if f and f not in self._hist: self._hist.insert(0,f)
        if self._cb: self._cb(f)

    def _clear(self):
        self._v.set("")
        if self._cb: self._cb("")

    def _set(self,f):
        self._v.set(f); self._apply()

    def get(self)->str: return self._v.get().strip()
    def set(self,f):    self._v.set(f)


# ════════════════════════════════════════════════════════════════════════════
#  INTERFACE SELECTOR (startup dialog + sidebar)
# ════════════════════════════════════════════════════════════════════════════
class InterfaceDialog(tk.Toplevel):
    r"""
    Interface selector - opens on startup.
    Shows only ACTIVE interfaces with FRIENDLY names.
    On Windows: resolves \Device\NPF_{GUID} to "Wi-Fi", "Ethernet 2" etc.
    Filters out inactive (no IP, link-local 169.254.x.x) adapters.
    """

    def __init__(self, par):
        super().__init__(par)
        self.title("NetScope — Select Interface")
        self.configure(bg=BG)
        self.geometry("820x540")
        self.resizable(True, True)
        self.result = None
        self._iface_map: Dict[str, str] = {}  # friendly_display → raw scapy name
        self._show_all  = tk.BooleanVar(value=False)
        self.transient(par)
        self._build()
        self.grab_set()
        self.update_idletasks()
        pw = par.winfo_width();  ph = par.winfo_height()
        px = par.winfo_x();      py = par.winfo_y()
        self.geometry(f"820x540+{px+(pw-820)//2}+{py+(ph-540)//2}")

    # ── Windows: GUID → friendly name via registry ────────────────────────
    @staticmethod
    def _win_guid_to_friendly() -> Dict[str, str]:
        """Return {GUID_uppercase: friendly_name} from Windows registry."""
        result: Dict[str, str] = {}
        if not IS_WIN:
            return result
        try:
            import winreg
            NET_KEY = (r"SYSTEM\CurrentControlSet\Control\Network"
                       r"\{4D36E972-E325-11CE-BFC1-08002BE10318}")
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, NET_KEY) as nk:
                idx = 0
                while True:
                    try:
                        guid = winreg.EnumKey(nk, idx); idx += 1
                        try:
                            conn = f"{NET_KEY}\\{guid}\\Connection"
                            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, conn) as ck:
                                name, _ = winreg.QueryValueEx(ck, "Name")
                                result[guid.upper()] = str(name)
                        except Exception:
                            pass
                    except OSError:
                        break
        except Exception:
            pass
        return result

    # ── Windows: parse ipconfig /all for rich adapter info ───────────────
    @staticmethod
    def _win_ipconfig() -> Dict[str, Dict]:
        """
        Parse `ipconfig /all` output.
        Returns {friendly_name: {ip, mask, gateway, dns, mac, dhcp, status}}
        """
        info: Dict[str, Dict] = {}
        if not IS_WIN:
            return info
        try:
            import subprocess
            out = subprocess.run(
                ["ipconfig", "/all"], capture_output=True, timeout=6,
                text=True, encoding="utf-8", errors="replace"
            ).stdout
            current: Optional[str] = None
            cur_data: Dict = {}
            for line in out.splitlines():
                # New adapter block
                if line and not line.startswith(" ") and ":" in line:
                    if current and cur_data:
                        info[current] = cur_data
                    # Strip "adapter " prefix and trailing ":"
                    name = line.split("adapter ", 1)[-1].rstrip(": \t")
                    current = name; cur_data = {}
                    continue
                stripped = line.strip()
                if not stripped or not current:
                    continue
                sl = stripped.lower()
                if "ipv4 address" in sl:
                    ip = stripped.split(":", 1)[-1].strip().split("(")[0].strip()
                    cur_data["ip"] = ip
                elif "subnet mask" in sl:
                    cur_data["mask"] = stripped.split(":", 1)[-1].strip()
                elif "default gateway" in sl:
                    gw = stripped.split(":", 1)[-1].strip()
                    if gw: cur_data["gateway"] = gw
                elif "dns servers" in sl:
                    cur_data["dns"] = stripped.split(":", 1)[-1].strip()
                elif "physical address" in sl:
                    cur_data["mac"] = stripped.split(":", 1)[-1].strip()
                elif "dhcp enabled" in sl:
                    cur_data["dhcp"] = "yes" in sl
                elif "media state" in sl:
                    cur_data["media"] = stripped.split(":", 1)[-1].strip()
                elif "description" in sl:
                    cur_data["desc"] = stripped.split(":", 1)[-1].strip()
            if current and cur_data:
                info[current] = cur_data
        except Exception:
            pass
        return info

    # ── Classify interface type from friendly name ────────────────────────
    @staticmethod
    def _classify(name: str, desc: str = "") -> Tuple[str, str]:
        """Returns (type_label, icon)"""
        n = (name + " " + desc).lower()
        if any(x in n for x in ("wi-fi","wifi","wlan","wireless","802.11","wl ")):
            return "Wi-Fi", "📡"
        if any(x in n for x in ("loopback","lo "," lo","127.")):
            return "Loopback", "🔁"
        if any(x in n for x in ("vpn","tunnel","tap","tun","pptp","l2tp","openvpn","nordvpn","expressvpn")):
            return "VPN", "🔐"
        if any(x in n for x in ("bluetooth","bt ")):
            return "Bluetooth", "📶"
        if any(x in n for x in ("virtual","vmware","virtualbox","hyper-v","vethernet","docker","vbox")):
            return "Virtual", "💻"
        return "Ethernet", "🔌"

    # ── Determine if IP is "real" (not link-local, not loopback) ─────────
    @staticmethod
    def _ip_active(ip: str) -> str:
        """Returns 'active', 'link-local', 'loopback', or 'inactive'"""
        if not ip or ip in ("N/A", "", "0.0.0.0"):
            return "inactive"
        if ip.startswith("127."):
            return "loopback"
        if ip.startswith("169.254."):
            return "link-local"
        return "active"

    # ── Build UI ──────────────────────────────────────────────────────────
    def _build(self):
        # Header
        hf = tk.Frame(self, bg=BG3, height=58)
        hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf, text="  ⬡  NetScope", bg=BG3, fg=ACC,
                 font=SXL).pack(side="left", padx=16, pady=8)
        tk.Label(hf, text="Select a network interface to start capturing",
                 bg=BG3, fg=FG2, font=S).pack(side="left", pady=8)

        # Show-all toggle
        tk.Checkbutton(hf, text="Show all adapters",
                       variable=self._show_all, bg=BG3, fg=FG3,
                       selectcolor=BG3, activebackground=BG3,
                       activeforeground=FG2, font=SS,
                       command=self._load_ifaces
                       ).pack(side="right", padx=16)

        # Legend bar
        leg = tk.Frame(self, bg=BG4, height=24)
        leg.pack(fill="x"); leg.pack_propagate(False)
        for txt, fg in [(" ● Active (has IP + gateway) ", GRN),
                         ("  ◑ Link-local (no DHCP) ", YEL),
                         ("  ○ Inactive ", FG3)]:
            tk.Label(leg, text=txt, bg=BG4, fg=fg, font=SS
                     ).pack(side="left", padx=2)

        # Interface list
        lf = tk.Frame(self, bg=BG2)
        lf.pack(fill="both", expand=True, padx=12, pady=(6,4))

        # Columns: icon | friendly name | raw name (hidden) | IP | type | status | gateway
        cols = ("ico","friendly","ip","type","status","gateway","speed")
        hdrs = (" ", "Interface Name", "IP Address", "Type", "Status", "Gateway", "")
        wids = [28, 210, 145, 90, 90, 130, 0]

        self._t = ttk.Treeview(lf, columns=cols, show="headings",
                                selectmode="browse", height=11)
        for c, h, w in zip(cols, hdrs, wids):
            self._t.heading(c, text=h)
            self._t.column(c, width=w, minwidth=0, stretch=(c=="friendly"))
        self._t.column("speed", width=0, minwidth=0)  # hidden raw name column

        # Tag colours
        self._t.tag_configure("active",     foreground=GRN,  background="#061a0a")
        self._t.tag_configure("link_local", foreground=YEL,  background="#1a1500")
        self._t.tag_configure("inactive",   foreground=FG3,  background=BG2)
        self._t.tag_configure("loopback",   foreground=FG4,  background=BG2)
        self._t.tag_configure("selected_active", foreground=GRN, background=SEL)

        vs = _vsb(lf, self._t)
        vs.pack(side="right", fill="y")
        self._t.pack(fill="both", expand=True)
        self._t.bind("<Double-1>", lambda e: self._start())

        # Status message
        self._status_lbl = tk.Label(self, text="", bg=BG, fg=FG2, font=SS, anchor="w")
        self._status_lbl.pack(fill="x", padx=16, pady=(0,2))

        # Options
        of = tk.Frame(self, bg=BG3)
        of.pack(fill="x", padx=12, pady=4)
        for row, (lbl, attr, default, width) in enumerate([
            ("Capture Filter (BPF):", "_bpf", "", 42),
            ("Max Packets (0=∞):",    "_cnt", "0", 10),
        ]):
            tk.Label(of, text=lbl, bg=BG3, fg=FG2, font=S
                     ).grid(row=row, column=0, padx=10, pady=5, sticky="w")
            sv = tk.StringVar(value=default); setattr(self, attr, sv)
            tk.Entry(of, textvariable=sv, width=width,
                     bg=BG4, fg=GRN, insertbackground=GRN,
                     relief="flat", font=M, highlightthickness=1,
                     highlightcolor=BORD2, highlightbackground=BORD
                     ).grid(row=row, column=1, padx=4, pady=5, sticky="w")
        # BPF hint
        tk.Label(of, text="e.g. tcp port 80  or  not arp  or  leave blank for everything",
                 bg=BG3, fg=FG3, font=SS
                 ).grid(row=0, column=2, padx=12, sticky="w")

        # Buttons
        bf = tk.Frame(self, bg=BG)
        bf.pack(fill="x", padx=12, pady=8)
        _btn(bf, "▶  Start Capturing", GRN, self._start,
             padx=18, pady=7).pack(side="left", padx=4)
        _btn(bf, "🔄  Refresh", ACC, self._load_ifaces,
             padx=12, pady=7).pack(side="left", padx=4)
        _btn(bf, "Cancel", FG2, self.destroy,
             padx=12, pady=7).pack(side="right", padx=4)

        tip = ("⚡  Double-click to start immediately.   "
               "Active (green) interfaces have a real IP and can capture traffic.")
        tk.Label(self, text=tip, bg=BG, fg=FG3, font=SS,
                 anchor="w").pack(fill="x", padx=16, pady=(0,6))

        # Load
        self._load_ifaces()

    # ── Main interface loading logic ──────────────────────────────────────
    def _load_ifaces(self):
        self._t.delete(*self._t.get_children())
        self._iface_map.clear()
        self._status_lbl.configure(text="  Scanning adapters…", fg=FG2)
        self.update()

        if not SCAPY:
            self._t.insert("", "end", tags=("inactive",),
                values=("✗", "Scapy not installed — run: pip install scapy",
                        "", "", "", "", ""))
            self._status_lbl.configure(text="  ⚠  Scapy not installed", fg=RED)
            return

        try:
            raw_ifaces = get_if_list()
        except Exception as e:
            self._t.insert("", "end", tags=("inactive",),
                values=("✗", f"Error listing interfaces: {e}", "", "", "", "", ""))
            self._status_lbl.configure(text=f"  Error: {e}", fg=RED)
            return

        if not raw_ifaces:
            self._t.insert("", "end", tags=("inactive",),
                values=("—", "No interfaces found — check permissions", "", "", "", "", ""))
            self._status_lbl.configure(text="  No interfaces found", fg=YEL)
            return

        # ── Gather Windows-specific info ──────────────────────────────────
        guid_map:   Dict[str, str] = {}   # GUID → friendly name
        ipcfg_map:  Dict[str, Dict] = {}  # friendly name → ipconfig data
        if IS_WIN:
            guid_map  = self._win_guid_to_friendly()
            ipcfg_map = self._win_ipconfig()

        # ── Build enriched info for each raw interface ────────────────────
        entries = []
        for raw in raw_ifaces:
            # 1. Resolve friendly name
            friendly = raw  # fallback = raw name
            ipdata: Dict = {}

            if IS_WIN:
                # Extract GUID from \Device\NPF_{GUID}
                guid = ""
                if "NPF_" in raw.upper():
                    parts = raw.upper().split("NPF_")
                    if len(parts) > 1:
                        guid = parts[1].strip("{}")
                if guid and guid in guid_map:
                    friendly = guid_map[guid]
                    # Look up ipconfig data by friendly name
                    for fname, fdata in ipcfg_map.items():
                        if fname.lower() == friendly.lower():
                            ipdata = fdata; break
                    # Fallback: match by description
                    if not ipdata:
                        for fname, fdata in ipcfg_map.items():
                            if friendly.lower() in fname.lower() or \
                               fname.lower() in friendly.lower():
                                ipdata = fdata; break
                else:
                    # Try matching by name directly
                    for fname, fdata in ipcfg_map.items():
                        if raw.lower() in fname.lower():
                            friendly = fname; ipdata = fdata; break

            # 2. Get IP address
            ip = ipdata.get("ip", "")
            if not ip:
                try:
                    ip = get_if_addr(raw)
                except Exception:
                    ip = ""
            if ip in ("", "0.0.0.0", None):
                ip = "N/A"

            # Media disconnected?
            media = ipdata.get("media", "").lower()
            if "disconnected" in media:
                ip = "Disconnected"

            # 3. Classify type
            desc = ipdata.get("desc", "")
            itype, ico = self._classify(friendly, desc)

            # 4. Determine activity status
            state = self._ip_active(ip)
            if "disconnected" in ip.lower():
                state = "inactive"

            # 5. Gateway
            gateway = ipdata.get("gateway", "")

            # 6. Build display status
            if state == "active":
                status_txt = "● Active"
            elif state == "link-local":
                status_txt = "◑ Link-local"
                gateway = ""
            elif state == "loopback":
                status_txt = "↩ Loopback"
            else:
                status_txt = "○ Inactive"

            entries.append({
                "raw":      raw,
                "friendly": friendly,
                "ip":       ip,
                "type":     itype,
                "ico":      ico,
                "state":    state,
                "status":   status_txt,
                "gateway":  gateway,
            })

        # ── Sort: active first, then link-local, then inactive ────────────
        order = {"active": 0, "link-local": 1, "loopback": 2, "inactive": 3}
        entries.sort(key=lambda x: (order.get(x["state"], 9), x["friendly"].lower()))

        # ── Filter: hide inactive unless "show all" checked ───────────────
        show_all  = self._show_all.get()
        n_active  = sum(1 for e in entries if e["state"] == "active")
        n_visible = 0
        first_active_id = None

        for e in entries:
            skip = (not show_all and
                    e["state"] in ("inactive", "loopback") and
                    n_active > 0)
            if skip:
                continue

            tag = e["state"].replace("-", "_")  # link-local → link_local

            # Store raw name in hidden "speed" column (reusing for internal use)
            iid = self._t.insert("", "end", tags=(tag,),
                values=(e["ico"], e["friendly"], e["ip"],
                        e["type"], e["status"], e["gateway"],
                        e["raw"]))  # raw scapy name stored here

            self._iface_map[iid] = e["raw"]  # iid → raw scapy name
            n_visible += 1

            if e["state"] == "active" and first_active_id is None:
                first_active_id = iid

        # ── Auto-select best interface ────────────────────────────────────
        if first_active_id:
            self._t.selection_set(first_active_id)
            self._t.see(first_active_id)
        else:
            kids = self._t.get_children()
            if kids:
                self._t.selection_set(kids[0])
                self._t.see(kids[0])

        # ── Status message ────────────────────────────────────────────────
        n_all = len(entries)
        hidden = n_all - n_visible
        msg = f"  {n_active} active  │  {n_visible} shown"
        if hidden and not show_all:
            msg += f"  │  {hidden} inactive hidden  (enable 'Show all adapters' to see them)"
        self._status_lbl.configure(
            text=msg,
            fg=GRN if n_active > 0 else YEL)

        if n_active == 0 and not show_all:
            self._show_all.set(True)
            self._load_ifaces()

    # ── Start capture ─────────────────────────────────────────────────────
    def _start(self):
        sel = self._t.selection()
        if not sel:
            messagebox.showwarning("No Interface",
                "Please select a network interface.", parent=self)
            return

        iid = sel[0]

        # Get raw Scapy interface name from our map or the hidden column
        raw_name = self._iface_map.get(iid, "")
        if not raw_name:
            # Fallback: read from hidden column
            raw_name = self._t.set(iid, "speed")
        if not raw_name:
            messagebox.showerror("Error",
                "Could not determine interface name.", parent=self)
            return

        # Warn if selecting inactive
        state_txt = self._t.set(iid, "status")
        if "Inactive" in state_txt or "Disconnected" in state_txt:
            ok = messagebox.askyesno("Inactive Interface",
                f"The selected interface appears inactive.\n\n"
                f"Capture may return no packets.\n\n"
                f"Continue anyway?", parent=self)
            if not ok:
                return

        try:
            cnt = int(self._cnt.get() or "0")
        except ValueError:
            cnt = 0

        self.result = {
            "iface": raw_name,
            "bpf":   self._bpf.get().strip(),
            "count": cnt,
        }
        self.destroy()


# ════════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ════════════════════════════════════════════════════════════════════════════
class NetScope(tk.Tk):
    APP  = "NetScope"
    VER  = "2.0"
    TAG  = "Professional Network Analyzer"

    def __init__(self):
        super().__init__()
        self.title(f"{self.APP} — {self.TAG}")
        self.geometry("1440x900")
        self.minsize(1024,700)
        self.configure(bg=BG)

        self._q:queue.Queue = queue.Queue()
        self._parser = Parser()
        self._pkts:  List[Pkt] = []
        self._running = False
        self._pcount  = 0
        self._t_start = None
        self._capfile = None
        self._iface   = ""
        self._bpf     = ""
        self._find_q  = ""

        self._style()
        self._fix_compositor()
        self._build_menu()
        self._build_toolbar()
        self._build_filter_bar()
        self._build_panes()
        self._build_statusbar()
        self.after(40, self._poll)

        # Keyboard shortcuts
        binds = [
            ("<Control-o>",self._open),   ("<Control-s>",self._save),
            ("<Control-q>",self.quit),     ("<Control-f>",self._find),
            ("<F3>",self._find_next),      ("<Control-g>",self._goto),
            ("<Control-k>",self._clear),   ("<Control-e>",self._expert),
            ("<F5>",self._start_capture),  ("<F6>",self._stop_capture),
            ("<Escape>",self._stop_capture),("<Home>",self._goto_first),
            ("<End>",self._goto_last),     ("m",self._mark_pkt),
        ]
        for k,c in binds: self.bind(k,lambda e,fn=c:fn())

        # ── Show interface selector right away ────────────────────────────
        self.after(100, self._auto_open_interface_dialog)

    # ── Compositor fix (prevents black window on Windows) ────────────────────
    def _fix_compositor(self):
        self.update_idletasks(); self.update()
        self.lift(); self.focus_force()
        if IS_WIN:
            self.wm_attributes("-alpha",0.98)
            self.after(80,  lambda:self.wm_attributes("-alpha",1.0))
            self.after(300, lambda:[self.update(),self.lift()])
            self.after(120, lambda:self.state("normal"))

    # ── Auto open interface dialog on startup ─────────────────────────────────
    def _auto_open_interface_dialog(self):
        if not SCAPY:
            messagebox.showerror("Scapy Not Found",
                "Scapy is required for packet capture.\n\n"
                "Install:  pip install scapy\n\n"
                "Windows also needs Npcap:\n"
                "  1. Go to: https://npcap.com/#download\n"
                "  2. Install with WinPcap-compatible mode ✓\n"
                "  3. Run this app as Administrator\n\n"
                "Linux/macOS: run with sudo\n\n"
                "You can still open saved .pcap files without Scapy.",
                parent=self)
            return
        dlg=InterfaceDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self._do_start(**dlg.result)

    # ── TTK style ─────────────────────────────────────────────────────────────
    def _style(self):
        s=ttk.Style(self); s.theme_use("clam")
        s.configure(".",background=BG2,foreground=FG,fieldbackground=BG3,
                    bordercolor=BORD,troughcolor=BG3,selectbackground=SEL,
                    insertcolor=GRN)
        s.configure("Treeview",background=BG2,foreground=FG,
                    fieldbackground=BG2,rowheight=21,font=MS,borderwidth=0)
        s.configure("Treeview.Heading",background=BG3,foreground=ACC,
                    font=SB,relief="flat",borderwidth=1,bordercolor=BORD)
        s.map("Treeview",background=[("selected",SEL)],foreground=[("selected",SEL2)])
        s.map("Treeview.Heading",background=[("active",BG4)])
        s.configure("TNotebook",background=BG,borderwidth=0)
        s.configure("TNotebook.Tab",background=BG3,foreground=FG2,
                    padding=[12,5],font=SB)
        s.map("TNotebook.Tab",background=[("selected",BG2)],
              foreground=[("selected",FG)])
        s.configure("TPanedwindow",background=BORD2)

    # ── Menu ──────────────────────────────────────────────────────────────────
    def _build_menu(self):
        bar=tk.Menu(self,bg=BG3,fg=FG,activebackground=SEL,
                    activeforeground=SEL2,relief="flat",bd=0)
        self.configure(menu=bar)
        def _m(label):
            m=tk.Menu(bar,tearoff=0,bg=BG3,fg=FG,activebackground=SEL,
                      activeforeground=SEL2,font=SS,relief="flat",bd=1)
            bar.add_cascade(label=f" {label} ",menu=m); return m

        fm=_m("File")
        for l,c in [("Open Capture…  Ctrl+O",self._open),
                    ("Save Capture…  Ctrl+S",self._save),
                    ("Save As…",self._save_as),(None,None),
                    ("Export → CSV…",self._exp_csv),
                    ("Export → JSON…",self._exp_json),
                    ("Export → Text…",self._exp_txt),(None,None),
                    ("Quit  Ctrl+Q",self.quit)]:
            if l: fm.add_command(label=l,command=c)
            else: fm.add_separator()

        em=_m("Edit")
        for l,c in [("Find Packet…  Ctrl+F",self._find),
                    ("Find Next  F3",self._find_next),
                    ("Go To Packet…  Ctrl+G",self._goto),(None,None),
                    ("Mark Packet  M",self._mark_pkt),
                    ("Mark All Displayed",self._mark_all),
                    ("Unmark All",self._unmark_all),(None,None),
                    ("Clear List  Ctrl+K",self._clear),
                    ("Copy Summary Line",self._copy_summary)]:
            if l: em.add_command(label=l,command=c)
            else: em.add_separator()

        vm=_m("View")
        self._tv=tk.StringVar(value="relative")
        for l,v in [("Time: Since Beginning","relative"),
                    ("Time: Absolute","absolute"),
                    ("Time: Since Previous","delta")]:
            vm.add_radiobutton(label=l,variable=self._tv,value=v,
                               command=self._time_changed)
        vm.add_separator()
        self._asv=tk.BooleanVar(value=True)
        vm.add_checkbutton(label="Auto-scroll to Latest",variable=self._asv)
        vm.add_separator()
        vm.add_command(label="Coloring Rules…",command=self._coloring_dlg)

        gm=_m("Go")
        for l,c in [("First Packet  Home",self._goto_first),
                    ("Last Packet   End",self._goto_last),
                    ("Go To Packet…  Ctrl+G",self._goto)]:
            gm.add_command(label=l,command=c)

        cm=_m("Capture")
        for l,c in [("Interfaces…",self._iface_dlg),
                    ("Start  F5",self._start_capture),
                    ("Stop   F6",self._stop_capture),
                    ("Restart",self._restart),(None,None),
                    ("BPF Filter Help…",self._bpf_help)]:
            if l: cm.add_command(label=l,command=c)
            else: cm.add_separator()

        am=_m("Analyze")
        for l,c in [("Follow TCP Stream",self._follow_stream),
                    (None,None),
                    ("Expert Info  Ctrl+E",self._expert),
                    (None,None),
                    ("Decode As…",lambda:messagebox.showinfo(
                        "Decode As","Use display filter to filter by protocol."))]:
            if l: am.add_command(label=l,command=c)
            else: am.add_separator()

        sm=_m("Statistics")
        for l,c in [("Capture Summary",self._summary),
                    (None,None),
                    ("Protocol Hierarchy",self._proto_hier),
                    ("Conversations",self._convos),
                    ("Endpoints",self._endpoints),
                    (None,None),
                    ("I/O Graph",self._io_graph),
                    (None,None),
                    ("DNS Queries",self._dns_stats),
                    ("Packet Lengths",self._pkt_lengths)]:
            if l: sm.add_command(label=l,command=c)
            else: sm.add_separator()

        hm=_m("Help")
        for l,c in [("About NetScope",self._about),
                    ("Keyboard Shortcuts",self._shortcuts),
                    (None,None),
                    ("Display Filter Help",self._filter_help),
                    ("BPF Capture Filter Help",self._bpf_help)]:
            if l: hm.add_command(label=l,command=c)
            else: hm.add_separator()

    # ── Toolbar ───────────────────────────────────────────────────────────────
    def _build_toolbar(self):
        tb=tk.Frame(self,bg="#080b10",height=48); tb.pack(fill="x")
        tb.pack_propagate(False)

        def _b(txt,fg,cmd,**kw):
            b=tk.Button(tb,text=txt,bg=BG3,fg=fg,font=SB,relief="flat",
                padx=9,pady=5,cursor="hand2",activebackground=BG4,
                activeforeground=fg,command=cmd,**kw)
            b.pack(side="left",padx=2,pady=7); return b
        def _sep():
            tk.Frame(tb,bg=BORD2,width=1,height=28).pack(side="left",padx=5,pady=10)

        tk.Label(tb,text=f"  ⬡ {self.APP}",bg="#080b10",
                 fg=ACC,font=SXL).pack(side="left",padx=(10,18))

        self._bs = _b("▶  Start",GRN,self._start_capture)
        self._bx = _b("■  Stop", RED,self._stop_capture)
        self._bx.configure(state="disabled",fg=FG3)
        _b("↺  Restart",YEL,self._restart)
        _sep()
        _b("📂  Open",ACC,self._open)
        _b("💾  Save",ACC,self._save)
        _sep()
        _b("🔍  Find",FG,self._find)
        _b("⬇  Last",FG,self._goto_last)
        _sep()
        _b("📊  Stats",PUR,self._proto_hier)
        _b("🔗  Stream",ORA,self._follow_stream)
        _b("⚠  Expert",RED,self._expert)
        _b("📈  Graph",GRN,self._io_graph)
        _sep()
        _b("🗑  Clear",FG2,self._clear)

        # Right side
        self._rl=tk.Label(tb,text="",bg="#080b10",fg=GRN,font=M)
        self._rl.pack(side="right",padx=10)
        self._il=tk.Label(tb,text="No interface",bg="#080b10",fg=FG3,font=MS)
        self._il.pack(side="right",padx=12)

    # ── Filter bar ────────────────────────────────────────────────────────────
    def _build_filter_bar(self):
        self._fb=FilterBar(self,on_apply=self._apply_filter)
        self._fb.pack(fill="x")

    # ── 3-pane layout ─────────────────────────────────────────────────────────
    def _build_panes(self):
        outer=ttk.PanedWindow(self,orient="vertical")
        outer.pack(fill="both",expand=True)

        self._pl=PktList(outer,on_select=self._on_select)
        self._pl.bind("<<FollowStream>>",lambda e:self._follow_stream())
        self._pl.bind("<<ApplyFilter>>", self._on_apply_evt)
        outer.add(self._pl,weight=5)

        bot=ttk.PanedWindow(outer,orient="horizontal")
        outer.add(bot,weight=3)

        self._dp=DetailPane(bot)
        bot.add(self._dp,weight=6)

        self._hp=HexPane(bot)
        bot.add(self._hp,weight=4)

    # ── Status bar ────────────────────────────────────────────────────────────
    def _build_statusbar(self):
        sb=tk.Frame(self,bg="#080b10",height=26)
        sb.pack(fill="x",side="bottom"); sb.pack_propagate(False)
        self._sv=tk.StringVar(value=f"  {self.APP} ready — select Capture → Interfaces to begin")
        tk.Label(sb,textvariable=self._sv,bg="#080b10",fg=FG2,
                 font=MS,anchor="w").pack(side="left",padx=8)
        self._ewl=tk.Label(sb,text="",bg="#080b10",fg=RED,font=SS)
        self._ewl.pack(side="right",padx=10)
        self._pl2=tk.Label(sb,text="Packets: 0",bg="#080b10",fg=GRN,font=MS)
        self._pl2.pack(side="right",padx=10)
        self._cl=tk.Label(sb,text="",bg="#080b10",fg=FG3,font=MS)
        self._cl.pack(side="right",padx=10)

    # ── Capture ───────────────────────────────────────────────────────────────
    def _iface_dlg(self):
        dlg=InterfaceDialog(self)
        self.wait_window(dlg)
        if dlg.result: self._do_start(**dlg.result)

    def _start_capture(self):
        if self._running: return
        self._iface_dlg()

    def _do_start(self,iface,bpf,count):
        if self._running: self._stop_capture()
        self._clear()
        self._parser.reset()
        self._pcount=0; self._running=True
        self._t_start=time.time()
        self._iface=iface; self._bpf=bpf
        self._il.configure(text=f"  ⬡ {iface}")
        self._bs.configure(state="disabled",fg=FG3)
        self._bx.configure(state="normal",  fg=RED)
        self._status(f"Capturing on {iface}" + (f"  [{bpf}]" if bpf else ""))
        t=threading.Thread(target=self._sniff_worker,args=(iface,bpf,count),daemon=True)
        t.start()
        self._update_rate()

    def _sniff_worker(self,iface,bpf,count):
        kw=dict(prn=self._pkt_cb,store=False,count=count)
        if iface: kw["iface"]=iface
        if bpf:   kw["filter"]=bpf
        try: sniff(**kw)
        except Exception as e: self._q.put(("ERR",str(e)))
        finally: self._q.put(("DONE",None))

    def _pkt_cb(self,pkt):
        self._pcount+=1
        try: self._q.put(("PKT",self._parser.parse(pkt,self._pcount)))
        except: pass

    def _stop_capture(self):
        if not self._running: return
        self._running=False
        self._bs.configure(state="normal",fg=GRN)
        self._bx.configure(state="disabled",fg=FG3)
        el=time.time()-(self._t_start or time.time())
        self._status(f"Stopped  │  {self._pcount:,} packets  │  {el:.1f}s")
        self._il.configure(text=f"  {self._iface} (stopped)")
        self._rl.configure(text="")

    def _restart(self):
        if self._iface:
            self._stop_capture()
            self.after(150,lambda:self._do_start(self._iface,self._bpf,0))
        else: self._start_capture()

    def _update_rate(self):
        if not self._running: return
        el=max(0.1,time.time()-(self._t_start or time.time()))
        self._rl.configure(text=f"{self._pcount/el:.1f} pkt/s")
        self.after(400,self._update_rate)

    # ── Queue poll ────────────────────────────────────────────────────────────
    def _poll(self):
        try:
            cnt=0
            while cnt<150:
                kind,data=self._q.get_nowait()
                if kind=="PKT": self._add(data)
                elif kind=="ERR":
                    self._running=False
                    self._bs.configure(state="normal",fg=GRN)
                    self._bx.configure(state="disabled",fg=FG3)
                    messagebox.showerror("Capture Error",
                        f"{data}\n\n"
                        "How to fix:\n"
                        "• Windows: Run as Administrator + install Npcap\n"
                        "• Linux:   sudo python3 netscope.py\n"
                        "• macOS:   sudo python3 netscope.py\n\n"
                        "Get Npcap: https://npcap.com/#download")
                elif kind=="DONE":
                    if self._running: self._stop_capture()
                cnt+=1
        except queue.Empty: pass
        self.after(40,self._poll)

    def _add(self,rec:Pkt):
        self._pkts.append(rec)
        filt=self._fb.get()
        if not filt or Filter.match(rec,filt):
            self._pl.append(rec,filt)
            if self._asv.get(): self._pl.scroll_end()
        total=len(self._pkts); disp=len(self._pl._t.get_children())
        self._pl2.configure(text=f"Pkts: {total:,}  Disp: {disp:,}")
        ex=sum(len(p.expert) for p in self._pkts)
        if ex: self._ewl.configure(text=f"⚠ {ex}")
        else:  self._ewl.configure(text="")

    # ── Packet select ─────────────────────────────────────────────────────────
    def _on_select(self,rec:Pkt):
        self._dp.show(rec); self._hp.show(rec.raw)
        src=(rec.src_ip or rec.src_mac or "?")
        dst=(rec.dst_ip or rec.dst_mac or "?")
        if rec.src_port: src+=f":{rec.src_port}"
        if rec.dst_port: dst+=f":{rec.dst_port}"
        ext=""
        if rec.rtt_ms>0: ext+=f"  RTT={rec.rtt_ms:.1f}ms"
        if rec.is_retx:  ext+="  [RETRANSMIT]"
        self._status(f"  #{rec.num}  {rec.proto}  {src} → {dst}  len={rec.length}  {rec.info[:70]}{ext}")

    # ── Display filter ────────────────────────────────────────────────────────
    def _apply_filter(self,filt):
        m=self._pl.apply_filter(filt)
        t=len(self._pkts)
        self._pl2.configure(text=f"Pkts: {t:,}  Disp: {m:,}")
        self._status(f"  Filter '{filt or 'none'}'  →  {m:,}/{t:,} packets shown")

    def _on_apply_evt(self,e):
        try: f=e.data; self._fb.set(f); self._apply_filter(f)
        except: pass

    # ── File ops ──────────────────────────────────────────────────────────────
    def _open(self):
        if not SCAPY: messagebox.showerror("Error","pip install scapy"); return
        p=filedialog.askopenfilename(
            filetypes=[("PCAP","*.pcap *.pcapng"),("All","*.*")],
            title="Open Capture File")
        if not p: return
        self._clear(); self._parser.reset(); self._pcount=0
        self._capfile=p
        self.title(f"{self.APP}  —  {os.path.basename(p)}")
        self._cl.configure(text=os.path.basename(p))
        self._status(f"  Loading {os.path.basename(p)}…"); self.update()
        threading.Thread(target=self._load_worker,args=(p,),daemon=True).start()

    def _load_worker(self,p):
        try:
            pkts=rdpcap(p)
            for pkt in pkts:
                self._pcount+=1
                self._q.put(("PKT",self._parser.parse(pkt,self._pcount)))
            self._q.put(("DONE",None))
        except Exception as e: self._q.put(("ERR",str(e)))

    def _save(self):
        if self._capfile: self._do_save(self._capfile)
        else: self._save_as()

    def _save_as(self):
        p=filedialog.asksaveasfilename(defaultextension=".pcap",
            filetypes=[("PCAP","*.pcap"),("All","*.*")],title="Save Capture")
        if p: self._capfile=p; self._do_save(p)

    def _do_save(self,p):
        if not self._pkts: messagebox.showinfo("Empty","No packets to save."); return
        try:
            from scapy.all import Ether as ScEth, Raw as ScRaw
            out=[]
            for rec in self._pkts:
                try:    out.append(ScEth(rec.raw))
                except: out.append(ScRaw(rec.raw))
            wrpcap(p,out)
            self._status(f"  Saved {len(out):,} packets → {p}")
            messagebox.showinfo("Saved",f"Saved {len(out):,} packets to:\n{p}")
        except Exception as e: messagebox.showerror("Save Error",str(e))

    def _exp_csv(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",
            filetypes=[("CSV","*.csv"),("All","*.*")])
        if not p: return
        try:
            with open(p,"w",encoding="utf-8") as f:
                f.write("No.,Time,Source,SrcPort,Destination,DstPort,"
                        "Protocol,Length,Flags,TTL,Stream,Info\n")
                for r in self._pkts:
                    f.write(f"{r.num},{r.t_rel:.6f},{r.src_ip or r.src_mac},"
                            f"{r.src_port},{r.dst_ip or r.dst_mac},{r.dst_port},"
                            f"{r.proto},{r.length},{r.flags},{r.ttl},{r.stream_id},"
                            f"\"{r.info.replace(chr(34),chr(39))}\"\n")
            messagebox.showinfo("Exported",f"CSV saved:\n{p}")
        except Exception as e: messagebox.showerror("Error",str(e))

    def _exp_json(self):
        p=filedialog.asksaveasfilename(defaultextension=".json",
            filetypes=[("JSON","*.json"),("All","*.*")])
        if not p: return
        try:
            data=[{"num":r.num,"time":r.t_rel,"proto":r.proto,
                   "src":r.src_ip or r.src_mac,"src_port":r.src_port,
                   "dst":r.dst_ip or r.dst_mac,"dst_port":r.dst_port,
                   "length":r.length,"flags":r.flags,"ttl":r.ttl,
                   "stream":r.stream_id,"retransmit":r.is_retx,
                   "rtt_ms":r.rtt_ms,"info":r.info,
                   "expert":[{"sev":s,"msg":m} for s,m in r.expert]}
                  for r in self._pkts]
            with open(p,"w",encoding="utf-8") as f: json.dump(data,f,indent=2)
            messagebox.showinfo("Exported",f"JSON saved:\n{p}")
        except Exception as e: messagebox.showerror("Error",str(e))

    def _exp_txt(self):
        p=filedialog.asksaveasfilename(defaultextension=".txt",
            filetypes=[("Text","*.txt"),("All","*.*")])
        if not p: return
        try:
            with open(p,"w",encoding="utf-8") as f:
                f.write(f"NetScope Capture Export — {datetime.now()}\n")
                f.write(f"Packets: {len(self._pkts):,}\n"+"="*80+"\n\n")
                for r in self._pkts:
                    f.write(f"#{r.num}  {r.t_rel:.6f}s  {r.proto}  {r.length}B"
                            f"  {r.src_ip}:{r.src_port} → {r.dst_ip}:{r.dst_port}\n"
                            f"  {r.info}\n{'─'*60}\n")
            messagebox.showinfo("Exported",f"Text saved:\n{p}")
        except Exception as e: messagebox.showerror("Error",str(e))

    # ── Navigation ────────────────────────────────────────────────────────────
    def _find(self):
        q=simpledialog.askstring("Find","Search by IP, port, protocol, or keyword:",
            parent=self,initialvalue=self._find_q)
        if q is not None: self._find_q=q; self._find_next()

    def _find_next(self):
        if not self._find_q: self._find(); return
        n=self._pl.find(self._find_q)
        if n: self._pl.select(n); self._status(f"  Found packet #{n}")
        else: messagebox.showinfo("Not Found",f"No packet matching '{self._find_q}'")

    def _goto(self):
        n=simpledialog.askinteger("Go To","Packet number:",parent=self,
            minvalue=1,maxvalue=max(self._pcount,1))
        if n: self._pl.select(n)

    def _goto_first(self):
        ch=self._pl._t.get_children()
        if ch: self._pl._t.selection_set(ch[0]); self._pl._t.see(ch[0])

    def _goto_last(self):
        ch=self._pl._t.get_children()
        if ch: self._pl._t.selection_set(ch[-1]); self._pl._t.see(ch[-1])

    # ── Mark ─────────────────────────────────────────────────────────────────
    def _mark_pkt(self): self._pl._mark()
    def _mark_all(self):
        for r in self._pkts: r.marked=True
        self._pl.refresh()
    def _unmark_all(self):
        for r in self._pkts: r.marked=False
        self._pl.refresh()
    def _copy_summary(self):
        r=self._pl.selected()
        if r: self.clipboard_clear(); self.clipboard_append(
            f"{r.num}\t{r.t_rel:.6f}\t{r.src_ip}\t{r.dst_ip}\t{r.proto}\t{r.info}")

    # ── Clear ─────────────────────────────────────────────────────────────────
    def _clear(self):
        self._pkts.clear(); self._pl.clear(); self._dp.clear(); self._hp.clear()
        self._parser.reset(); self._pcount=0
        self._pl2.configure(text="Packets: 0"); self._ewl.configure(text="")
        self._cl.configure(text=""); self._capfile=None
        self.title(f"{self.APP} — {self.TAG}")
        self._status("  Cleared")

    # ── Stats ─────────────────────────────────────────────────────────────────
    def _need(self):
        if not self._pkts:
            messagebox.showinfo("No Data","Capture or open a file first."); return False
        return True

    def _proto_hier(self):
        if self._need(): ProtoDialog(self,self._pkts)
    def _convos(self):
        if self._need(): ConvoDialog(self,self._pkts)
    def _endpoints(self):
        if self._need(): EndpointDialog(self,self._pkts)
    def _io_graph(self):
        if self._need(): IODialog(self,self._pkts)
    def _expert(self):
        ExpertDialog(self,self._pkts)
    def _follow_stream(self):
        r=self._pl.selected()
        if not r or r.stream_id<0:
            messagebox.showinfo("Follow Stream","Select a TCP packet first."); return
        s=Stats(self._pkts); txt,cli,srv=s.follow_stream(r.stream_id)
        StreamDialog(self,txt,cli,srv,r.stream_id)

    def _dns_stats(self):
        if not self._need(): return
        dlg=_Dlg(self,"DNS Query Statistics",720,480)
        dlg._hdr("Top DNS Queries")
        t=dlg._tf(dlg,("rank","domain","count"),
                  ("Rank","Domain","Queries"),[70,400,100],["e","w","e"])
        t.tag_configure("t1",foreground=ACC); t.tag_configure("t2",foreground=GRN)
        s=Stats(self._pkts)
        for i,(dom,cnt) in enumerate(s.dns_top(),1):
            t.insert("","end",values=(f"#{i}",dom,cnt),
                     tags=(f"t{min(i,2)}",))
        if not s.dns_top():
            t.insert("","end",values=("","No DNS traffic",""))
        dlg._cls()

    def _pkt_lengths(self):
        if not self._need(): return
        dlg=_Dlg(self,"Packet Length Distribution",560,400)
        dlg._hdr("Packet Length Distribution")
        t=dlg._tf(dlg,("rng","cnt","pct","bytes"),
                  ("Length Range","Packets","%","Bytes"),
                  [160,90,80,120],["w","e","e","e"])
        bkts=[(0,63),(64,127),(128,255),(256,511),(512,1023),(1024,1517),(1518,9999)]
        total=len(self._pkts)
        for lo,hi in bkts:
            grp=[p for p in self._pkts if lo<=p.length<=hi]
            cnt=len(grp); b=sum(p.length for p in grp)
            pct=cnt/total*100 if total else 0
            t.insert("","end",values=(f"{lo}–{hi} bytes",f"{cnt:,}",f"{pct:.1f}%",f"{b:,}"))
        dlg._cls()

    def _summary(self):
        if not self._pkts: messagebox.showinfo("Summary","No packets yet."); return
        n=len(self._pkts); dur=self._pkts[-1].t_rel if n else 0
        avg=n/dur if dur>0.001 else 0
        tb=sum(p.length for p in self._pkts)
        retx=sum(1 for p in self._pkts if p.is_retx)
        ex=sum(len(p.expert) for p in self._pkts)
        protos=Counter(p.proto for p in self._pkts)
        top="\n".join(f"  {pr}: {c:,}" for pr,c in protos.most_common(10))
        messagebox.showinfo("Capture Summary",
            f"File:         {self._capfile or '(live capture)'}\n"
            f"Interface:    {self._iface or 'N/A'}\n"
            f"Packets:      {n:,}\n"
            f"Duration:     {dur:.3f}s\n"
            f"Avg Rate:     {avg:.1f} pkt/s\n"
            f"Total Data:   {tb:,} bytes  ({tb/1024/1024:.2f} MB)\n"
            f"Avg Size:     {tb//n if n else 0} B/pkt\n"
            f"Retransmits:  {retx:,}\n"
            f"Expert Msgs:  {ex:,}\n\n"
            f"Protocols:\n{top}")

    # ── Coloring rules ────────────────────────────────────────────────────────
    def _coloring_dlg(self):
        dlg=tk.Toplevel(self); dlg.title("Coloring Rules")
        dlg.configure(bg=BG); dlg.geometry("640,440")
        dlg.geometry("640x440"); dlg.transient(self)
        tk.Label(dlg,text="  🎨  Coloring Rules",bg=BG,fg=ACC,font=SL
                 ).pack(padx=16,pady=(10,4),anchor="w")
        f=tk.Frame(dlg,bg=BG2); f.pack(fill="both",expand=True,padx=12,pady=4)
        t=ttk.Treeview(f,columns=("name","fg","bg"),show="headings",height=14)
        for c,h,w in zip(("name","fg","bg"),("Rule","Foreground","Background"),[220,130,130]):
            t.heading(c,text=h); t.column(c,width=w)
        vs=_vsb(f,t); vs.pack(side="right",fill="y"); t.pack(fill="both",expand=True)
        for name,(fg,bg) in [
            ("TCP RST",RST_COLOR),("TCP SYN",SYN_COLOR),
            ("HTTP",PROTO_COLORS["HTTP"]),("TLS/HTTPS",PROTO_COLORS["TLS"]),
            ("DNS",PROTO_COLORS["DNS"]),("DHCP",PROTO_COLORS["DHCP"]),
            ("ICMP",PROTO_COLORS["ICMP"]),("ARP",PROTO_COLORS["ARP"]),
            ("UDP",PROTO_COLORS["UDP"]),("TCP",PROTO_COLORS["TCP"]),
            ("Retransmit",RETX_COLOR),("Marked",MARK_COLOR),
        ]:
            tag=f"cr_{name}"
            t.tag_configure(tag,foreground=fg,background=bg)
            t.insert("","end",values=(name,fg,bg),tags=(tag,))
        _btn(dlg,"Close",FG2,dlg.destroy).pack(pady=8)

    # ── Time mode ─────────────────────────────────────────────────────────────
    def _time_changed(self): self._pl.set_time_mode(self._tv.get())

    # ── Status ────────────────────────────────────────────────────────────────
    def _status(self,m): self._sv.set(m)

    # ── About / help ──────────────────────────────────────────────────────────
    def _about(self):
        dlg=tk.Toplevel(self); dlg.title(f"About {self.APP}")
        dlg.configure(bg=BG); dlg.geometry("520x500"); dlg.resizable(False,False)
        dlg.transient(self)
        tk.Label(dlg,text=f"⬡  {self.APP}",bg=BG,fg=ACC,font=(SF,22,"bold")).pack(pady=(24,4))
        tk.Label(dlg,text=self.TAG,bg=BG,fg=FG2,font=S).pack()
        tk.Label(dlg,text=f"Version {self.VER}",bg=BG,fg=FG3,font=SS).pack(pady=4)
        ttk.Separator(dlg).pack(fill="x",padx=24,pady=10)
        feats=["✓  Live packet capture (Scapy + Npcap/libpcap)",
               "✓  Auto-capture on interface select",
               "✓  3-pane: Packet list / Detail tree / Hex dump",
               "✓  Full decode: ETH→IPv4/v6→TCP/UDP/ICMP/DNS/DHCP/NTP/HTTP/TLS",
               "✓  Display filter: tcp, ip.addr==x, frame.len>1000, not arp…",
               "✓  TCP stream tracking, RTT measurement, retransmit detection",
               "✓  Expert information (RST, zero-window, TTL, retransmit)",
               "✓  Protocol hierarchy, conversations, endpoints",
               "✓  I/O graph (packets/s or bytes/s vs time)",
               "✓  Follow TCP stream (ASCII payload reconstruction)",
               "✓  DNS analytics, packet length distribution",
               "✓  Export: PCAP / CSV / JSON / Text",
               "✓  Coloring rules (12 protocol rules)",
               "✓  Mark packets, comments, sort, find, go-to",
               "✓  Time modes: relative / absolute / delta"]
        for f in feats:
            tk.Label(dlg,text=f"  {f}",bg=BG,fg=FG,font=SS,anchor="w"
                     ).pack(fill="x",padx=24,pady=1)
        _btn(dlg,"Close",FG2,dlg.destroy,padx=14,pady=4).pack(pady=10)

    def _shortcuts(self):
        messagebox.showinfo("Keyboard Shortcuts",
            "F5 / Ctrl+F5    Start capture\n"
            "F6 / Esc        Stop capture\n"
            "Ctrl+O          Open PCAP file\n"
            "Ctrl+S          Save PCAP\n"
            "Ctrl+Q          Quit\n"
            "Ctrl+F          Find packet\n"
            "F3              Find next\n"
            "Ctrl+G          Go to packet #\n"
            "Ctrl+K          Clear list\n"
            "Ctrl+E          Expert information\n"
            "Home            First packet\n"
            "End             Last packet\n"
            "M               Mark / unmark\n\n"
            "Right-click packet → context menu")

    def _filter_help(self):
        messagebox.showinfo("Display Filter Reference",
            "Protocol filters:\n"
            "  tcp  udp  http  tls  https  dns  dhcp  icmp  arp  ntp\n"
            "  ip   ipv6   retransmission   expert\n\n"
            "Field comparisons:\n"
            "  ip.src == 1.2.3.4\n"
            "  ip.dst == 8.8.8.8\n"
            "  ip.addr == 192.168.1.1     (src OR dst)\n"
            "  tcp.port == 80             (src OR dst port)\n"
            "  tcp.srcport == 443\n"
            "  tcp.dstport == 22\n"
            "  udp.port == 53\n"
            "  eth.src == aa:bb:cc:dd:ee:ff\n"
            "  frame.len > 1000\n"
            "  frame.len < 64\n"
            "  tcp.flags == 0x002         (SYN packets)\n"
            "  tcp.stream == 0\n"
            "  ip.ttl < 10\n\n"
            "Boolean:\n"
            "  tcp and not dns\n"
            "  http or dns\n"
            "  not arp and not icmp\n"
            "  ip.addr == 8.8.8.8 and dns\n"
            "  (tcp or udp) and frame.len > 500\n\n"
            "Text search:\n"
            "  Just type a word — searches all fields")

    def _bpf_help(self):
        messagebox.showinfo("BPF Capture Filter Reference",
            "BPF filters apply AT CAPTURE TIME.\n"
            "They use libpcap syntax:\n\n"
            "  tcp                 — TCP only\n"
            "  udp                 — UDP only\n"
            "  icmp                — ICMP/ping\n"
            "  tcp port 80         — HTTP\n"
            "  tcp port 443        — HTTPS\n"
            "  udp port 53         — DNS\n"
            "  not arp             — exclude ARP\n"
            "  host 8.8.8.8        — one host\n"
            "  net 192.168.1.0/24  — subnet\n"
            "  port 80 or port 443 — multiple ports\n"
            "  tcp and not port 22 — TCP except SSH\n"
            "  greater 1000        — large packets\n"
            "  less 128            — small packets\n\n"
            "Leave blank to capture EVERYTHING.")


# ════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = NetScope()
    app.mainloop()
