@echo off
title NetScope — Setup
echo ============================================================
echo   NetScope — Setup and Dependency Installer
echo ============================================================
echo.

:: Check Python
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python not found.
    echo Download Python from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    echo.
    pause
    goto :eof
)
echo [OK] Python found:
python --version

echo.
echo [INFO] Installing/updating Scapy...
python -m pip install --upgrade scapy
if %ERRORLEVEL% NEQ 0 (
    echo [WARN] pip install failed. Try: python -m pip install scapy --user
    python -m pip install scapy --user
)

echo.
echo ============================================================
echo   NEXT STEP: Install Npcap (Windows packet capture driver)
echo ============================================================
echo.
echo   1. Open this URL in your browser:
echo      https://npcap.com/#download
echo.
echo   2. Download the latest Npcap installer
echo.
echo   3. Run the installer and CHECK this option:
echo      [x] Install Npcap in WinPcap API-compatible Mode
echo.
echo   4. Reboot if prompted
echo.
echo   5. Double-click START.bat to launch NetScope
echo.
set /p OPEN="Open npcap.com in browser now? (Y/n): "
if /i "!OPEN!" NEQ "n" (
    start https://npcap.com/#download
)

echo.
echo [DONE] Setup complete. Run START.bat to launch NetScope.
pause
